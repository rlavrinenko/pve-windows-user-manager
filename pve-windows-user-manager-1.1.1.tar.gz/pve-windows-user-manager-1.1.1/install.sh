#!/usr/bin/env bash
set -euo pipefail
NAME="pve-windows-user-manager"
VERSION="1.1.1"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PVE_ROOT="/usr/share/pve-manager"
INDEX="$PVE_ROOT/index.html.tpl"
JS_DIR="$PVE_ROOT/js"
BUNDLE="$JS_DIR/pvemanagerlib.js"
TARGET_JS="$JS_DIR/windows-user-manager.js"
BACKUP_DIR="/var/lib/$NAME/backups"

fail(){ echo "[PVE-WUM] ERROR: $*" >&2; exit 1; }
[[ ${EUID:-$(id -u)} -eq 0 ]] || fail "run as root"
command -v pveversion >/dev/null 2>&1 || fail "this host does not look like Proxmox VE"
[[ -f "$INDEX" ]] || fail "$INDEX not found"
[[ -f "$BUNDLE" ]] || fail "$BUNDLE not found"
[[ -f "$SRC_DIR/windows-user-manager.js" ]] || fail "windows-user-manager.js not found"

PVE_VER="$(pveversion pve-manager 2>/dev/null || true)"
echo "[PVE-WUM] Detected: ${PVE_VER:-Proxmox VE}"

# Remove the invasive auto-repair remnants from early test versions.
rm -f /etc/apt/apt.conf.d/99-pve-windows-user-manager
rm -f /usr/local/sbin/pve-wum-repair
rm -rf /usr/local/share/pve-windows-user-manager

mkdir -p "$BACKUP_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
cp -a "$INDEX" "$BACKUP_DIR/index.html.tpl.$TS"
cp -a "$BUNDLE" "$BACKUP_DIR/pvemanagerlib.js.$TS"

install -m 0644 "$SRC_DIR/windows-user-manager.js" "$TARGET_JS"

# Native VM-menu insertion: patch only the PVE.qemu.Config block in the UI bundle.
python3 "$SRC_DIR/patch-pvemanager.py" "$BUNDLE"

# Load runtime after the normal PVE bundle and force a new bundle URL so browsers
# cannot keep the pre-patch pvemanagerlib.js from cache.
python3 - "$INDEX" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
# Remove all old WUM loaders.
lines=[x for x in s.splitlines() if 'windows-user-manager.js' not in x]
s='\n'.join(lines)+'\n'
# Remove an old WUM cache suffix, then add the current one to pvemanagerlib.
s=re.sub(r'(&|&amp;)wum=[0-9.]+', '', s)
pat=r'(<script[^>]+src=["\']/pve2/js/pvemanagerlib\.js\?ver=\[% version %\])(["\'])'
m=re.search(pat,s)
if not m:
    raise SystemExit('Cannot find pvemanagerlib.js loader in index.html.tpl')
s=s[:m.start()] + m.group(1) + '&wum=1.1.1' + m.group(2) + s[m.end():]
lines=s.splitlines()
idx=next(i for i,x in enumerate(lines) if 'pvemanagerlib.js' in x and '<script' in x)
lines.insert(idx+1, '    <script type="text/javascript" src="/pve2/js/windows-user-manager.js?v=1.1.1"></script>')
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
PY

grep -q "const VERSION = '1.1.1'" "$TARGET_JS" || fail "wrong runtime version installed"
grep -q "PVE-WUM-NATIVE-BEGIN" "$BUNDLE" || fail "native QEMU menu patch missing"
grep -q "itemId: 'windows-users'" "$BUNDLE" || fail "Windows Users card missing from bundle"
grep -q "windows-user-manager.js?v=1.1.1" "$INDEX" || fail "runtime loader missing"
grep -q "pvemanagerlib.js.*wum=1.1.1" "$INDEX" || fail "bundle cache-buster missing"

systemctl restart pveproxy

echo "[PVE-WUM] Installed $VERSION"
echo "[PVE-WUM] Integration: native PVE.qemu.Config card (stock Ext.panel.Panel)"
echo "[PVE-WUM] Transport: QEMU Guest Agent only"
echo "[PVE-WUM] Open Proxmox in a new private window or Ctrl+Shift+R."
