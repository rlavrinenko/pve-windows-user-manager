# PVE Windows User Manager 1.0.0

VM-level management of local Windows users directly inside the Proxmox VE web interface.

## Transport

**QEMU Guest Agent only.** The module does not use WinRM, SSH, RDP, a custom Windows service, or an additional TCP/UDP port.

## Functions

- Load all local users from the selected Windows VM.
- Load all local groups from that VM, including localized/Cyrillic names.
- Create a local user and set its password.
- Set Full Name and Description.
- Add the user to any local groups returned by the VM.
- Edit Full Name, Description and group membership.
- Enable/disable a local account.
- Change a local user's password.
- Search users by name, full name, description or group.
- Identify existing users and groups internally by SID instead of localized names.

## Compatibility

The UI integration does not add a separate web service. It is loaded by the existing Proxmox interface on port 8006 and calls the built-in QEMU Guest Agent API.

QGA command formatting is negotiated automatically:

- newer PVE releases: JSON array command arguments;
- older PVE releases: legacy NUL-separated command arguments.

The installer does not hard-code a Proxmox major version and repairs the UI loader after `pve-manager` package upgrades through a dpkg post-invoke hook.

Inside Windows, ADSI/WinNT is used instead of relying on `Get-LocalUser`, so localized groups and older Windows/PowerShell installations are handled more broadly.

## Requirements

1. The VM is QEMU/KVM (not LXC).
2. Windows is running.
3. `qemu-guest-agent` is installed and running inside Windows.
4. `QEMU Guest Agent` is enabled in Proxmox VM Options.
5. The logged-in PVE account has `VM.GuestAgent.Unrestricted` for the VM. Root has it automatically.

## Install

```bash
cd pve-windows-user-manager
chmod +x install.sh
./install.sh
```

Then hard-refresh the browser with `Ctrl+F5` and open:

`VM -> Windows Users`

On a Proxmox cluster, install the UI module on each node from which administrators may open the web interface. The module can still manage a VM residing on another cluster node because the normal Proxmox API proxies the request to the VM's node.

## Uninstall

```bash
./uninstall.sh
```

No Windows-side cleanup is required because nothing is installed inside the guest.
