#!/usr/bin/env bash
set -euo pipefail

NAME="pve-windows-user-manager"
VERSION="1.0.0"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PVE_ROOT="/usr/share/pve-manager"
INDEX="$PVE_ROOT/index.html.tpl"
JS_DIR="$PVE_ROOT/js"
TARGET_JS="$JS_DIR/windows-user-manager.js"
PERSIST_DIR="/usr/local/share/$NAME"
REPAIR="/usr/local/sbin/pve-wum-repair"
APT_HOOK="/etc/apt/apt.conf.d/99-pve-windows-user-manager"
BACKUP_DIR="/var/lib/$NAME/backups"
MARKER='windows-user-manager.js'
QUIET=0

[[ "${1:-}" == "--quiet" ]] && QUIET=1
log(){ [[ $QUIET -eq 1 ]] || echo "[PVE-WUM] $*"; }
fail(){ echo "[PVE-WUM] ERROR: $*" >&2; exit 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || fail "run as root"
command -v pveversion >/dev/null 2>&1 || fail "this host does not look like Proxmox VE"
[[ -f "$INDEX" ]] || fail "$INDEX not found"
[[ -d "$JS_DIR" ]] || fail "$JS_DIR not found"
[[ -f "$SRC_DIR/windows-user-manager.js" ]] || fail "windows-user-manager.js not found next to install.sh"

PVE_VER="$(pveversion pve-manager 2>/dev/null || pveversion 2>/dev/null | head -n1 || true)"
log "Detected: ${PVE_VER:-Proxmox VE}"

mkdir -p "$PERSIST_DIR" "$BACKUP_DIR"
install -m 0644 "$SRC_DIR/windows-user-manager.js" "$PERSIST_DIR/windows-user-manager.js"
install -m 0644 "$SRC_DIR/windows-user-manager.js" "$TARGET_JS"

TS="$(date +%Y%m%d-%H%M%S)"
if ! grep -q "$MARKER" "$INDEX"; then
    cp -a "$INDEX" "$BACKUP_DIR/index.html.tpl.$TS"
fi

python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
line = '    <script type="text/javascript" src="/pve2/js/windows-user-manager.js?v=1.0.0"></script>'
# idempotent: remove older WUM loader lines, then insert after pvemanagerlib.js
s = '\n'.join(x for x in s.splitlines() if 'windows-user-manager.js' not in x) + '\n'
needle = '<script type="text/javascript" src="/pve2/js/pvemanagerlib.js?ver=[% version %]"></script>'
if needle not in s:
    # fallback for older/newer templates: match the pvemanagerlib filename regardless of query string
    lines = s.splitlines()
    idx = next((i for i,x in enumerate(lines) if 'pvemanagerlib.js' in x and '<script' in x), None)
    if idx is None:
        raise SystemExit('Cannot find pvemanagerlib.js loader in index.html.tpl')
    lines.insert(idx + 1, line)
    s = '\n'.join(lines) + '\n'
else:
    s = s.replace(needle, needle + '\n' + line, 1)
p.write_text(s, encoding='utf-8')
PY

cat > "$REPAIR" <<'REPAIR_EOF'
#!/usr/bin/env bash
set -euo pipefail
INDEX="/usr/share/pve-manager/index.html.tpl"
TARGET="/usr/share/pve-manager/js/windows-user-manager.js"
SOURCE="/usr/local/share/pve-windows-user-manager/windows-user-manager.js"
[[ -f "$INDEX" && -f "$SOURCE" ]] || exit 0
install -m 0644 "$SOURCE" "$TARGET"
python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text(encoding='utf-8')
line='    <script type="text/javascript" src="/pve2/js/windows-user-manager.js?v=1.0.0"></script>'
s='\n'.join(x for x in s.splitlines() if 'windows-user-manager.js' not in x)+'\n'
lines=s.splitlines()
idx=next((i for i,x in enumerate(lines) if 'pvemanagerlib.js' in x and '<script' in x), None)
if idx is None: raise SystemExit(0)
lines.insert(idx+1,line)
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
PY
exit 0
REPAIR_EOF
chmod 0755 "$REPAIR"

cat > "$APT_HOOK" <<'EOF_HOOK'
DPkg::Post-Invoke { "test ! -x /usr/local/sbin/pve-wum-repair || /usr/local/sbin/pve-wum-repair --quiet >/dev/null 2>&1 || true"; };
EOF_HOOK
chmod 0644 "$APT_HOOK"

# Sanity checks. pveproxy does not need a restart because it renders index.html.tpl per request.
grep -q "$MARKER" "$INDEX" || fail "UI loader was not installed"
[[ -s "$TARGET_JS" ]] || fail "JavaScript module was not installed"

log "Installed PVE Windows User Manager $VERSION"
log "Integration: VM -> Windows Users"
log "Transport: QEMU Guest Agent only"
log "No extra ports, WinRM, SSH or guest-side service are used."
log "If the tab is not visible, hard-refresh the browser (Ctrl+F5)."
