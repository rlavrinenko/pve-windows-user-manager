/*
 * PVE Windows User Manager
 * VM-level local Windows user management via QEMU Guest Agent only.
 * No WinRM, SSH, guest-side daemon or extra ports.
 */
(function () {
    'use strict';

    if (typeof Ext === 'undefined' || typeof PVE === 'undefined' || typeof Proxmox === 'undefined') {
        return;
    }

    const VERSION = '1.0.2';

    const i18n = {
        ru: {
            title: 'Windows Users', users: 'Локальные пользователи', refresh: 'Обновить', create: 'Создать', edit: 'Изменить',
            password: 'Пароль', enable: 'Включить', disable: 'Отключить', username: 'Пользователь', fullName: 'Полное имя',
            description: 'Описание', status: 'Статус', groups: 'Группы', sid: 'SID', enabled: 'Включен', disabled: 'Отключен',
            createTitle: 'Создать локального пользователя', editTitle: 'Карточка пользователя', passwordTitle: 'Изменить пароль',
            newPassword: 'Новый пароль', confirmPassword: 'Подтверждение пароля', save: 'Сохранить', cancel: 'Отмена',
            qgaRequired: 'QEMU Guest Agent недоступен. Включите QEMU Guest Agent в параметрах ВМ и установите qemu-guest-agent в Windows.',
            windowsOnly: 'Модуль доступен только для Windows ВМ.', loading: 'Загрузка пользователей и групп с ВМ…',
            noPermission: 'Нужна привилегия VM.GuestAgent.Unrestricted для этой ВМ.', error: 'Ошибка', success: 'Готово',
            selectUser: 'Выберите пользователя.', passwordsMismatch: 'Пароли не совпадают.', passwordRequired: 'Введите пароль.',
            usernameRequired: 'Введите имя пользователя.', confirmDisable: 'Отключить выбранного пользователя?', confirmEnable: 'Включить выбранного пользователя?',
            builtIn: 'Встроенная', ordinary: 'Локальная', type: 'Тип', agent: 'QEMU Guest Agent', version: 'Версия модуля',
            vmGroups: 'Локальные группы этой ВМ', search: 'Поиск', noUsers: 'Пользователи не найдены',
        },
        uk: {
            title: 'Windows Users', users: 'Локальні користувачі', refresh: 'Оновити', create: 'Створити', edit: 'Змінити',
            password: 'Пароль', enable: 'Увімкнути', disable: 'Вимкнути', username: 'Користувач', fullName: 'Повне ім’я',
            description: 'Опис', status: 'Статус', groups: 'Групи', sid: 'SID', enabled: 'Увімкнений', disabled: 'Вимкнений',
            createTitle: 'Створити локального користувача', editTitle: 'Картка користувача', passwordTitle: 'Змінити пароль',
            newPassword: 'Новий пароль', confirmPassword: 'Підтвердження пароля', save: 'Зберегти', cancel: 'Скасувати',
            qgaRequired: 'QEMU Guest Agent недоступний. Увімкніть QEMU Guest Agent у параметрах ВМ і встановіть qemu-guest-agent у Windows.',
            windowsOnly: 'Модуль доступний лише для Windows ВМ.', loading: 'Завантаження користувачів і груп з ВМ…',
            noPermission: 'Потрібен привілей VM.GuestAgent.Unrestricted для цієї ВМ.', error: 'Помилка', success: 'Готово',
            selectUser: 'Оберіть користувача.', passwordsMismatch: 'Паролі не збігаються.', passwordRequired: 'Введіть пароль.',
            usernameRequired: 'Введіть ім’я користувача.', confirmDisable: 'Вимкнути обраного користувача?', confirmEnable: 'Увімкнути обраного користувача?',
            builtIn: 'Вбудований', ordinary: 'Локальний', type: 'Тип', agent: 'QEMU Guest Agent', version: 'Версія модуля',
            vmGroups: 'Локальні групи цієї ВМ', search: 'Пошук', noUsers: 'Користувачів не знайдено',
        },
        en: {
            title: 'Windows Users', users: 'Local users', refresh: 'Refresh', create: 'Create', edit: 'Edit',
            password: 'Password', enable: 'Enable', disable: 'Disable', username: 'User', fullName: 'Full name',
            description: 'Description', status: 'Status', groups: 'Groups', sid: 'SID', enabled: 'Enabled', disabled: 'Disabled',
            createTitle: 'Create local user', editTitle: 'User card', passwordTitle: 'Change password',
            newPassword: 'New password', confirmPassword: 'Confirm password', save: 'Save', cancel: 'Cancel',
            qgaRequired: 'QEMU Guest Agent is unavailable. Enable QEMU Guest Agent in VM options and install qemu-guest-agent in Windows.',
            windowsOnly: 'This module is available only for Windows VMs.', loading: 'Loading users and groups from the VM…',
            noPermission: 'VM.GuestAgent.Unrestricted privilege is required for this VM.', error: 'Error', success: 'Done',
            selectUser: 'Select a user.', passwordsMismatch: 'Passwords do not match.', passwordRequired: 'Enter a password.',
            usernameRequired: 'Enter a username.', confirmDisable: 'Disable selected user?', confirmEnable: 'Enable selected user?',
            builtIn: 'Built-in', ordinary: 'Local', type: 'Type', agent: 'QEMU Guest Agent', version: 'Module version',
            vmGroups: 'Local groups on this VM', search: 'Search', noUsers: 'No users found',
        },
    };

    function lang() {
        let l = (Proxmox.defaultLang || 'en').toLowerCase();
        if (l.startsWith('ru')) return 'ru';
        if (l.startsWith('uk') || l.startsWith('ua')) return 'uk';
        return 'en';
    }

    function t(key) {
        return i18n[lang()][key] || i18n.en[key] || key;
    }

    function utf8ToB64(str) {
        if (window.TextEncoder) {
            const bytes = new TextEncoder().encode(str);
            let s = '';
            const chunk = 0x8000;
            for (let i = 0; i < bytes.length; i += chunk) {
                s += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunk, bytes.length)));
            }
            return btoa(s);
        }
        return btoa(unescape(encodeURIComponent(str)));
    }

    function b64ToUtf8(b64) {
        const bin = atob(b64);
        if (window.TextDecoder) {
            const bytes = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
            return new TextDecoder('utf-8').decode(bytes);
        }
        return decodeURIComponent(escape(bin));
    }

    function psEncodedCommand(script) {
        const bytes = new Uint8Array(script.length * 2);
        for (let i = 0; i < script.length; i++) {
            const c = script.charCodeAt(i);
            bytes[i * 2] = c & 0xff;
            bytes[i * 2 + 1] = c >> 8;
        }
        let s = '';
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
            s += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunk, bytes.length)));
        }
        return btoa(s);
    }

    function apiRequest(opts) {
        return new Promise((resolve, reject) => {
            Ext.Ajax.request({
                url: opts.url,
                method: opts.method || 'GET',
                jsonData: opts.jsonData,
                params: opts.params,
                timeout: opts.timeout || 60000,
                headers: opts.method && opts.method !== 'GET' ? {
                    CSRFPreventionToken: Proxmox.CSRFPreventionToken,
                } : undefined,
                success: function (response) {
                    try {
                        const obj = Ext.decode(response.responseText);
                        resolve(obj.data);
                    } catch (e) {
                        reject(new Error('Invalid API response'));
                    }
                },
                failure: function (response) {
                    let msg = response.statusText || 'API error';
                    try {
                        const obj = Ext.decode(response.responseText);
                        if (obj && obj.errors) {
                            msg = Object.keys(obj.errors).map(k => `${k}: ${obj.errors[k]}`).join('\n');
                        } else if (obj && obj.message) {
                            msg = obj.message;
                        }
                    } catch (e) {
                        if (response.responseText) msg = response.responseText;
                    }
                    const err = new Error(msg);
                    err.status = response.status;
                    err.responseText = response.responseText;
                    reject(err);
                },
            });
        });
    }

    function isLegacyArrayError(err) {
        const s = String((err && (err.message + ' ' + err.responseText)) || '').toLowerCase();
        return s.includes('command') && (s.includes('array') || s.includes('schema') || s.includes('property'));
    }

    const PS_BASE = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding

function Write-PveResult([object]$obj) {
    $json = $obj | ConvertTo-Json -Depth 12 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    [Console]::Out.WriteLine('PVEWUM:' + [Convert]::ToBase64String($bytes))
}

function Get-SidValue([object]$entry) {
    try {
        $raw = $entry.psbase.Properties['objectSid'].Value
        if ($null -eq $raw) { return $null }
        return (New-Object System.Security.Principal.SecurityIdentifier($raw, 0)).Value
    } catch { return $null }
}

function Get-Prop([object]$entry, [string]$name, $default = $null) {
    try {
        $v = $entry.psbase.Properties[$name].Value
        if ($null -eq $v) { return $default }
        return $v
    } catch { return $default }
}

function Find-EntryBySid([object]$computer, [string]$sid, [string]$className) {
    foreach ($c in @($computer.psbase.Children)) {
        if ($c.SchemaClassName -ne $className) { continue }
        if ((Get-SidValue $c) -eq $sid) { return $c }
    }
    throw "$className SID $sid not found"
}

function Get-GroupMembers([object]$group) {
    $result = @()
    try {
        foreach ($m in @($group.psbase.Invoke('Members'))) {
            try {
                $type = $m.GetType()
                $name = $type.InvokeMember('Name', 'GetProperty', $null, $m, $null)
                $cls = $type.InvokeMember('Class', 'GetProperty', $null, $m, $null)
                $path = $type.InvokeMember('ADsPath', 'GetProperty', $null, $m, $null)
                $sid = $null
                try { $sid = Get-SidValue ([ADSI]$path) } catch {}
                $result += [pscustomobject]@{ name = [string]$name; class = [string]$cls; path = [string]$path; sid = $sid }
            } catch {}
        }
    } catch {}
    return @($result)
}

function Read-State([object]$computer) {
    $groups = @()
    $users = @()
    $groupMembersBySid = @{}

    foreach ($c in @($computer.psbase.Children)) {
        if ($c.SchemaClassName -eq 'Group') {
            $sid = Get-SidValue $c
            $members = @(Get-GroupMembers $c)
            $groupMembersBySid[$sid] = $members
            $groups += [pscustomobject]@{
                name = [string](Get-Prop $c 'Name' '')
                description = [string](Get-Prop $c 'Description' '')
                sid = $sid
                members = $members
            }
        }
    }

    foreach ($c in @($computer.psbase.Children)) {
        if ($c.SchemaClassName -ne 'User') { continue }
        $sid = Get-SidValue $c
        $flags = [int](Get-Prop $c 'UserFlags' 0)
        $userGroups = @()
        foreach ($g in $groups) {
            foreach ($m in @($groupMembersBySid[$g.sid])) {
                if (($m.sid -and $m.sid -eq $sid) -or (!$m.sid -and $m.name -eq [string](Get-Prop $c 'Name' ''))) {
                    $userGroups += [pscustomobject]@{ name = $g.name; sid = $g.sid }
                    break
                }
            }
        }
        $rid = $null
        if ($sid -match '-(\d+)$') { $rid = [int]$Matches[1] }
        $users += [pscustomobject]@{
            name = [string](Get-Prop $c 'Name' '')
            fullName = [string](Get-Prop $c 'FullName' '')
            description = [string](Get-Prop $c 'Description' '')
            sid = $sid
            enabled = (($flags -band 2) -eq 0)
            userFlags = $flags
            builtIn = ($rid -in @(500,501,503,504))
            groups = @($userGroups)
        }
    }

    return [pscustomobject]@{
        computer = $env:COMPUTERNAME
        users = @($users | Sort-Object name)
        groups = @($groups | Sort-Object name)
    }
}

try {
    $payloadJson = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__PAYLOAD__'))
    $p = $payloadJson | ConvertFrom-Json
    $computer = [ADSI]("WinNT://" + $env:COMPUTERNAME + ",computer")

    switch ([string]$p.op) {
        'list' {
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'create' {
            if ([string]::IsNullOrWhiteSpace([string]$p.username)) { throw 'Username is required' }
            if ([string]::IsNullOrEmpty([string]$p.password)) { throw 'Password is required' }
            $u = $computer.psbase.Children.Add([string]$p.username, 'user')
            $u.psbase.Invoke('SetPassword', [string]$p.password)
            if ($null -ne $p.fullName) { $u.Put('FullName', [string]$p.fullName) }
            if ($null -ne $p.description) { $u.Put('Description', [string]$p.description) }
            $u.SetInfo()
            $u = [ADSI]("WinNT://" + $env:COMPUTERNAME + "/" + [string]$p.username + ",user")
            foreach ($gsid in @($p.groups)) {
                if ([string]::IsNullOrWhiteSpace([string]$gsid)) { continue }
                $g = Find-EntryBySid $computer ([string]$gsid) 'Group'
                try { $g.psbase.Invoke('Add', $u.Path) } catch {
                    if ($_.Exception.Message -notmatch 'already') { throw }
                }
            }
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'update' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            if ($null -ne $p.fullName) { $u.Put('FullName', [string]$p.fullName) }
            if ($null -ne $p.description) { $u.Put('Description', [string]$p.description) }
            $u.SetInfo()

            $wanted = @{}
            foreach ($gsid in @($p.groups)) { if ($gsid) { $wanted[[string]$gsid] = $true } }
            foreach ($g in @($computer.psbase.Children)) {
                if ($g.SchemaClassName -ne 'Group') { continue }
                $gsid = Get-SidValue $g
                if (!$gsid) { continue }
                $isMember = $false
                foreach ($m in @(Get-GroupMembers $g)) {
                    if ($m.sid -eq [string]$p.sid) { $isMember = $true; break }
                }
                if ($wanted.ContainsKey($gsid) -and !$isMember) {
                    $g.psbase.Invoke('Add', $u.Path)
                } elseif (!$wanted.ContainsKey($gsid) -and $isMember) {
                    $g.psbase.Invoke('Remove', $u.Path)
                }
            }
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'enabled' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            $flags = [int](Get-Prop $u 'UserFlags' 0)
            if ([bool]$p.enabled) { $flags = $flags -band (-bnot 2) } else { $flags = $flags -bor 2 }
            $u.Put('UserFlags', $flags)
            $u.SetInfo()
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'password' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            if ([string]::IsNullOrEmpty([string]$p.password)) { throw 'Password is required' }
            $u.psbase.Invoke('SetPassword', [string]$p.password)
            $u.SetInfo()
            Write-PveResult ([pscustomobject]@{ ok = $true })
        }
        default { throw ('Unknown operation: ' + [string]$p.op) }
    }
} catch {
    Write-PveResult ([pscustomobject]@{ ok = $false; error = $_.Exception.Message })
}
`;

    const WUM = {
        version: VERSION,

        baseUrl(node, vmid) {
            return `/api2/json/nodes/${encodeURIComponent(node)}/qemu/${encodeURIComponent(vmid)}`;
        },

        async osInfo(node, vmid) {
            return apiRequest({ url: this.baseUrl(node, vmid) + '/agent/get-osinfo', method: 'GET', timeout: 10000 });
        },

        buildCommand(payload) {
            const payload64 = utf8ToB64(Ext.encode(payload));
            const script = PS_BASE.replace('__PAYLOAD__', payload64);
            return [
                'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
                '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', psEncodedCommand(script),
            ];
        },

        async exec(node, vmid, payload) {
            const url = this.baseUrl(node, vmid) + '/agent/exec';
            const cmd = this.buildCommand(payload);
            let data;
            try {
                data = await apiRequest({ url, method: 'POST', jsonData: { command: cmd }, timeout: 30000 });
            } catch (e) {
                if (!isLegacyArrayError(e)) throw e;
                // PVE 7 compatibility: array parameters used to be represented as a NUL-separated string.
                data = await apiRequest({ url, method: 'POST', jsonData: { command: cmd.join('\u0000') }, timeout: 30000 });
            }
            if (!data || data.pid === undefined) throw new Error('QEMU Guest Agent did not return a PID');
            return this.wait(node, vmid, data.pid);
        },

        async wait(node, vmid, pid) {
            const url = this.baseUrl(node, vmid) + '/agent/exec-status';
            const started = Date.now();
            while (Date.now() - started < 90000) {
                const s = await apiRequest({ url, method: 'GET', params: { pid }, timeout: 15000 });
                if (s && s.exited) {
                    const out = s['out-data'] || '';
                    const lines = String(out).split(/\r?\n/).reverse();
                    const marker = lines.find(x => x.indexOf('PVEWUM:') === 0);
                    if (!marker) {
                        const err = s['err-data'] || `PowerShell exited with code ${s.exitcode}`;
                        throw new Error(err || 'No result returned by Windows');
                    }
                    let result;
                    try { result = Ext.decode(b64ToUtf8(marker.substring(7))); } catch (e) { throw new Error('Cannot decode Windows response'); }
                    if (!result.ok) throw new Error(result.error || 'Windows operation failed');
                    return result;
                }
                await new Promise(resolve => Ext.defer(resolve, 300));
            }
            throw new Error('QEMU Guest Agent command timeout');
        },
    };

    PVE.WindowsUserManager = WUM;

    function groupItems(groups, selected) {
        const sel = {};
        (selected || []).forEach(g => sel[g.sid || g] = true);
        return (groups || []).map(g => ({
            boxLabel: Ext.htmlEncode(g.name),
            name: 'group_' + g.sid,
            inputValue: g.sid,
            checked: !!sel[g.sid],
            margin: '0 18 6 0',
        }));
    }

    function selectedGroups(form, groups) {
        const vals = form.getValues();
        return (groups || []).filter(g => {
            const v = vals['group_' + g.sid];
            return v === true || v === 'on' || v === g.sid || (Array.isArray(v) && v.length);
        }).map(g => g.sid);
    }

    Ext.define('PVE.window.WindowsUserCreate', {
        extend: 'Ext.window.Window',
        modal: true,
        width: 620,
        height: 610,
        layout: 'fit',
        title: t('createTitle'),
        node: undefined,
        vmid: undefined,
        groups: undefined,
        onSuccess: Ext.emptyFn,

        initComponent: function () {
            const me = this;
            me.form = Ext.create('Ext.form.Panel', {
                bodyPadding: 14,
                border: false,
                autoScroll: true,
                defaults: { anchor: '100%', labelWidth: 150 },
                items: [
                    { xtype: 'textfield', fieldLabel: t('username'), name: 'username', allowBlank: false, maxLength: 64 },
                    { xtype: 'textfield', fieldLabel: t('fullName'), name: 'fullName', maxLength: 256 },
                    { xtype: 'textarea', fieldLabel: t('description'), name: 'description', height: 90, maxLength: 1024 },
                    { xtype: 'textfield', inputType: 'password', fieldLabel: t('newPassword'), name: 'password', allowBlank: false },
                    { xtype: 'textfield', inputType: 'password', fieldLabel: t('confirmPassword'), name: 'confirm', allowBlank: false },
                    { xtype: 'displayfield', value: '<b>' + Ext.htmlEncode(t('vmGroups')) + '</b>', margin: '10 0 8 0' },
                    { xtype: 'checkboxgroup', columns: 2, vertical: true, items: groupItems(me.groups, []) },
                ],
            });
            Ext.apply(me, {
                items: [me.form],
                buttons: [
                    { text: t('save'), iconCls: 'fa fa-check', handler: async function () {
                        if (!me.form.isValid()) return;
                        const v = me.form.getForm().getValues();
                        if (!v.username) return Ext.Msg.alert(t('error'), t('usernameRequired'));
                        if (!v.password) return Ext.Msg.alert(t('error'), t('passwordRequired'));
                        if (v.password !== v.confirm) return Ext.Msg.alert(t('error'), t('passwordsMismatch'));
                        const btn = this; btn.setDisabled(true); me.setLoading(true);
                        try {
                            const r = await WUM.exec(me.node, me.vmid, {
                                op: 'create', username: v.username, fullName: v.fullName || '', description: v.description || '',
                                password: v.password, groups: selectedGroups(me.form.getForm(), me.groups),
                            });
                            me.onSuccess(r.data); me.close();
                        } catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message)); }
                        finally { if (!me.destroyed) { me.setLoading(false); btn.setDisabled(false); } }
                    }},
                    { text: t('cancel'), handler: function () { me.close(); } },
                ],
            });
            me.callParent();
        },
    });

    Ext.define('PVE.window.WindowsUserEdit', {
        extend: 'Ext.window.Window', modal: true, width: 640, height: 560, layout: 'fit', title: t('editTitle'),
        node: undefined, vmid: undefined, groups: undefined, user: undefined, onSuccess: Ext.emptyFn,
        initComponent: function () {
            const me = this;
            me.form = Ext.create('Ext.form.Panel', {
                bodyPadding: 14, border: false, autoScroll: true,
                defaults: { anchor: '100%', labelWidth: 150 },
                items: [
                    { xtype: 'displayfield', fieldLabel: t('username'), value: Ext.htmlEncode(me.user.name) },
                    { xtype: 'displayfield', fieldLabel: t('sid'), value: Ext.htmlEncode(me.user.sid || '') },
                    { xtype: 'textfield', fieldLabel: t('fullName'), name: 'fullName', value: me.user.fullName || '', maxLength: 256 },
                    { xtype: 'textarea', fieldLabel: t('description'), name: 'description', value: me.user.description || '', height: 100, maxLength: 1024 },
                    { xtype: 'displayfield', value: '<b>' + Ext.htmlEncode(t('vmGroups')) + '</b>', margin: '10 0 8 0' },
                    { xtype: 'checkboxgroup', columns: 2, vertical: true, items: groupItems(me.groups, me.user.groups || []) },
                ],
            });
            Ext.apply(me, { items: [me.form], buttons: [
                { text: t('save'), iconCls: 'fa fa-check', handler: async function () {
                    const btn = this; btn.setDisabled(true); me.setLoading(true);
                    const v = me.form.getForm().getValues();
                    try {
                        const r = await WUM.exec(me.node, me.vmid, { op: 'update', sid: me.user.sid,
                            fullName: v.fullName || '', description: v.description || '', groups: selectedGroups(me.form.getForm(), me.groups) });
                        me.onSuccess(r.data); me.close();
                    } catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message)); }
                    finally { if (!me.destroyed) { me.setLoading(false); btn.setDisabled(false); } }
                }},
                { text: t('cancel'), handler: function () { me.close(); } },
            ]});
            me.callParent();
        },
    });

    Ext.define('PVE.window.WindowsUserPassword', {
        extend: 'Ext.window.Window', modal: true, width: 470, height: 220, layout: 'fit', title: t('passwordTitle'),
        node: undefined, vmid: undefined, user: undefined, onSuccess: Ext.emptyFn,
        initComponent: function () {
            const me = this;
            me.form = Ext.create('Ext.form.Panel', { bodyPadding: 14, border: false, defaults: { anchor: '100%', labelWidth: 160 }, items: [
                { xtype: 'displayfield', fieldLabel: t('username'), value: Ext.htmlEncode(me.user.name) },
                { xtype: 'textfield', inputType: 'password', fieldLabel: t('newPassword'), name: 'password', allowBlank: false },
                { xtype: 'textfield', inputType: 'password', fieldLabel: t('confirmPassword'), name: 'confirm', allowBlank: false },
            ]});
            Ext.apply(me, { items: [me.form], buttons: [
                { text: t('save'), iconCls: 'fa fa-key', handler: async function () {
                    if (!me.form.isValid()) return;
                    const v = me.form.getForm().getValues();
                    if (v.password !== v.confirm) return Ext.Msg.alert(t('error'), t('passwordsMismatch'));
                    const btn = this; btn.setDisabled(true); me.setLoading(true);
                    try { await WUM.exec(me.node, me.vmid, { op: 'password', sid: me.user.sid, password: v.password }); me.onSuccess(); me.close(); }
                    catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message)); }
                    finally { if (!me.destroyed) { me.setLoading(false); btn.setDisabled(false); } }
                }},
                { text: t('cancel'), handler: function () { me.close(); } },
            ]});
            me.callParent();
        },
    });

    Ext.define('PVE.panel.WindowsUserManager', {
        extend: 'Ext.panel.Panel',
        alias: 'widget.pveWindowsUserManager',
        layout: 'fit',
        border: false,
        node: undefined,
        vmid: undefined,

        initComponent: function () {
            const me = this;
            me.groups = [];
            me.store = Ext.create('Ext.data.Store', {
                fields: ['name', 'fullName', 'description', 'sid', 'enabled', 'builtIn', 'groups'],
                data: [],
                sorters: [{ property: 'name', direction: 'ASC' }],
            });

            function rec() { return me.grid.getSelectionModel().getSelection()[0]; }
            function loadState(state) {
                if (!state) return;
                me.groups = state.groups || [];
                me.store.loadData(state.users || []);
            }
            me.loadState = loadState;

            me.grid = Ext.create('Ext.grid.Panel', {
                store: me.store,
                border: false,
                viewConfig: { emptyText: t('noUsers'), deferEmptyText: false },
                columns: [
                    { text: t('username'), dataIndex: 'name', width: 180, renderer: Ext.htmlEncode },
                    { text: t('fullName'), dataIndex: 'fullName', width: 200, renderer: Ext.htmlEncode },
                    { text: t('status'), dataIndex: 'enabled', width: 105, renderer: v => v ? '<span style="color:#3b8b3b"><i class="fa fa-check-circle"></i> ' + t('enabled') + '</span>' : '<span style="color:#a94442"><i class="fa fa-ban"></i> ' + t('disabled') + '</span>' },
                    { text: t('type'), dataIndex: 'builtIn', width: 105, renderer: v => v ? t('builtIn') : t('ordinary') },
                    { text: t('description'), dataIndex: 'description', flex: 1, minWidth: 220, renderer: v => Ext.htmlEncode(v || '') },
                    { text: t('groups'), dataIndex: 'groups', width: 300, renderer: v => (v || []).map(g => Ext.htmlEncode(g.name)).join(', ') },
                    { text: t('sid'), dataIndex: 'sid', width: 250, hidden: true, renderer: Ext.htmlEncode },
                ],
                listeners: { itemdblclick: function () { me.editUser(); }, selectionchange: function () { me.updateButtons(); } },
                tbar: [
                    { text: t('refresh'), iconCls: 'fa fa-refresh', handler: () => me.reload() },
                    { itemId: 'createBtn', text: t('create'), iconCls: 'fa fa-user-plus', handler: () => me.createUser() },
                    { itemId: 'editBtn', text: t('edit'), iconCls: 'fa fa-pencil', disabled: true, handler: () => me.editUser() },
                    { itemId: 'passwordBtn', text: t('password'), iconCls: 'fa fa-key', disabled: true, handler: () => me.passwordUser() },
                    '-',
                    { itemId: 'toggleBtn', text: t('disable'), iconCls: 'fa fa-ban', disabled: true, handler: () => me.toggleUser() },
                    '->',
                    { xtype: 'textfield', width: 240, emptyText: t('search'), enableKeyEvents: true, listeners: { change: function (f, v) {
                        me.store.clearFilter(); if (!v) return; const q = String(v).toLowerCase();
                        me.store.filterBy(r => [r.get('name'), r.get('fullName'), r.get('description')].concat((r.get('groups') || []).map(g => g.name)).join(' ').toLowerCase().includes(q));
                    }}},
                ],
            });

            Ext.apply(me, { items: [me.grid], listeners: { activate: function () { if (!me.loadedOnce) me.reload(); } } });
            me.callParent();
        },

        updateButtons: function () {
            const me = this, r = me.grid.getSelectionModel().getSelection()[0];
            ['editBtn', 'passwordBtn', 'toggleBtn'].forEach(id => me.grid.down('#' + id).setDisabled(!r));
            if (r) {
                const b = me.grid.down('#toggleBtn');
                b.setText(r.get('enabled') ? t('disable') : t('enable'));
                b.setIconCls(r.get('enabled') ? 'fa fa-ban' : 'fa fa-check');
            }
        },

        reload: async function () {
            const me = this; me.setLoading(t('loading'));
            try {
                let os;
                try { os = await WUM.osInfo(me.node, me.vmid); }
                catch (e) {
                    if (String(e.message).includes('permission') || String(e.message).includes('403')) throw new Error(t('noPermission'));
                    throw new Error(t('qgaRequired'));
                }
                const info = os && os.result ? os.result : os;
                const id = String((info && (info.id || info.name || info['pretty-name'])) || '').toLowerCase();
                if (id && !id.includes('windows') && !id.includes('microsoft')) throw new Error(t('windowsOnly'));
                const r = await WUM.exec(me.node, me.vmid, { op: 'list' });
                me.loadState(r.data); me.loadedOnce = true;
            } catch (e) { me.store.removeAll(); Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message)); }
            finally { me.setLoading(false); me.updateButtons(); }
        },

        createUser: function () {
            const me = this;
            Ext.create('PVE.window.WindowsUserCreate', { node: me.node, vmid: me.vmid, groups: me.groups, onSuccess: state => me.loadState(state) }).show();
        },
        editUser: function () {
            const me = this, r = me.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            Ext.create('PVE.window.WindowsUserEdit', { node: me.node, vmid: me.vmid, groups: me.groups, user: Ext.clone(r.data), onSuccess: state => me.loadState(state) }).show();
        },
        passwordUser: function () {
            const me = this, r = me.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            Ext.create('PVE.window.WindowsUserPassword', { node: me.node, vmid: me.vmid, user: Ext.clone(r.data), onSuccess: () => me.reload() }).show();
        },
        toggleUser: function () {
            const me = this, r = me.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            const target = !r.get('enabled');
            Ext.Msg.confirm(target ? t('enable') : t('disable'), target ? t('confirmEnable') : t('confirmDisable'), async function (ans) {
                if (ans !== 'yes') return; me.setLoading(true);
                try { const res = await WUM.exec(me.node, me.vmid, { op: 'enabled', sid: r.get('sid'), enabled: target }); me.loadState(res.data); }
                catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message)); }
                finally { me.setLoading(false); me.updateButtons(); }
            });
        },
    });

    // Integrate the module while PVE.panel.Config is still processing the VM's
    // declarative item list.  This is deliberately done BEFORE ConfigPanel builds
    // savedItems/tree nodes.  PVE 7.4 does not reliably activate cards appended to
    // an already initialized ConfigPanel (the tree selection changes but the old
    // card can stay visible).  Adding our item here uses the exact same activation
    // path as Summary/Hardware/Permissions and is compatible with PVE 7/8/9.
    const configPanelInit = PVE.panel.Config.prototype.initComponent;
    PVE.panel.Config.prototype.initComponent = function () {
        const me = this;
        try {
            const vm = me.pveSelNode && me.pveSelNode.data ? me.pveSelNode.data : null;
            const isQemu = !!(vm && vm.vmid && vm.node &&
                (vm.type === 'qemu' || String(vm.id || '').indexOf('qemu/') !== -1 ||
                 (PVE.qemu && PVE.qemu.Config && me instanceof PVE.qemu.Config)));

            if (isQemu && !vm.template) {
                me.items = me.items || [];
                const exists = me.items.some(function (item) {
                    return item && item.itemId === 'windows-users';
                });
                if (!exists) {
                    me.items.push({
                        title: t('title'),
                        itemId: 'windows-users',
                        iconCls: 'fa fa-users',
                        xtype: 'pveWindowsUserManager',
                        node: vm.node,
                        vmid: vm.vmid,
                    });
                }
            }
        } catch (e) {
            if (window.console && console.warn) console.warn('PVE Windows User Manager integration:', e);
        }
        return configPanelInit.apply(me, arguments);
    };
})();
