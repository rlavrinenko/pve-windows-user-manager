# PVE Windows User Manager 1.1.4

VM-level local Windows user management for Proxmox VE. Communication with Windows is **QEMU Guest Agent only** — no WinRM, SSH, extra service, or extra management port is required.

The module is integrated as a normal `Ext.panel.Panel` entry in the existing `PVE.qemu.Config` VM menu. Local users and groups are read from the selected Windows VM; localized group names and UTF-8/Cyrillic are preserved.

## Main features

- List local Windows users and local groups.
- Create, edit, enable/disable, and delete ordinary local users.
- Change passwords.
- Edit Full Name and Description.
- Add/remove users from VM-local groups.
- Advanced password flags: Password required, Password never expires, User cannot change password, Must change password at next logon.
- Random password generator with one-time Show/Copy controls.

## Password generator in 1.1.4

- Password length: **6–64 characters**.
- Independent character sets:
  - **ABC** — uppercase letters.
  - **abc** — lowercase letters.
  - **123** — digits.
  - **$?%** — special symbols.
- **Exclude similar characters** option removes characters such as `1, I, i, l, |, 0, O, o`.
- **Exclude ambiguous symbols** option removes visually/punctuation-heavy characters such as brackets, quotes, slashes, backticks, angle brackets, etc.
- At least one enabled character set is required.
- Every enabled character set contributes at least one character to the generated password.
- Show and Copy buttons are available only for the password generated in the current dialog. Manual password editing invalidates the generated-password copy state.

## Install / update

```bash
chmod +x *.sh
./install.sh
```

Diagnostics for VM 100:

```bash
./diagnose.sh 100
```

Emergency UI restore / uninstall integration:

```bash
./restore-panel.sh
```

A `pve-manager` package update can replace `pvemanagerlib.js`; rerun `install.sh` after such an update. No automatic dpkg/apt repair hook is installed.

## Version history

### 1.1.4

- Password length minimum changed from 12 to **6**.
- Added selectable `ABC`, `abc`, `123`, and special-symbol character sets.
- Added **Exclude similar characters**.
- Added **Exclude ambiguous symbols**.
- Password generator guarantees representation from every enabled set.

### 1.1.3

- Added random password generation to Create User and Change Password dialogs.
- Added temporary Show/Hide and Copy buttons for a newly generated password.

### 1.1.2

- Added deletion of ordinary local users with built-in account protection.
- Added advanced password flags and validation of incompatible options.

### 1.1.1

- Removed custom ExtJS classes using `initComponent()` / `callParent()` to fix PVE 7.4 / ExtJS 6.2 initialization errors.
- Main manager and dialogs use stock ExtJS panels/windows.
