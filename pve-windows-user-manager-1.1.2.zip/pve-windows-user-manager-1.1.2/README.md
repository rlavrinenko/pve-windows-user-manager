# PVE Windows User Manager 1.1.2

VM-level local Windows user management for Proxmox VE. Windows communication is **QEMU Guest Agent only**.

This release replaces the experimental dynamic ExtJS menu hooks used by 1.0.x. The installer now inserts one normal `Ext.panel.Panel` entry directly into the existing `PVE.qemu.Config` block in `pvemanagerlib.js`. Card switching therefore remains entirely stock Proxmox behavior. The actual user manager is mounted only after that native card is visible; any runtime error is shown inside the card.

Supported operations: list local users and VM-local groups, create a local user with password, edit full name/description, change password, enable/disable or delete a local account, update group membership, and manage advanced password flags (password required, password never expires, user cannot change password, and force password change at next logon). Group names come directly from the guest and UTF-8/Cyrillic is preserved.

Install:

```bash
chmod +x *.sh
./install.sh
```

Diagnostics:

```bash
./diagnose.sh 100
```

Uninstall / emergency UI restore:

```bash
./restore-panel.sh
```

A `pve-manager` package update replaces `pvemanagerlib.js`; rerun `install.sh` after such an update. No automatic dpkg/apt repair hook is installed.

## 1.1.1
- Removed all custom ExtJS classes that used `initComponent()` / `callParent()`.
- The main manager now uses only stock `Ext.panel.Panel` and `Ext.grid.Panel` instances.
- Create/Edit/Password dialogs now use stock `Ext.window.Window` instances.
- This specifically fixes the PVE 7.4 / ExtJS 6.2 `callParent` initialization crash.

## 1.1.2
- Added deletion of ordinary local Windows users with confirmation; built-in system accounts are protected.
- Added advanced password options to Create, Edit and Change Password dialogs.
- Added Password required, Password never expires, User cannot change password, and Must change password at next logon.
- Added conflict validation for incompatible password options.
