#!/usr/bin/env bash
set -euo pipefail
PVE_ROOT="/usr/share/pve-manager"
INDEX="$PVE_ROOT/index.html.tpl"
BUNDLE="$PVE_ROOT/js/pvemanagerlib.js"
TARGET_JS="$PVE_ROOT/js/windows-user-manager.js"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "run as root" >&2; exit 1; }
[[ -f "$BUNDLE" ]] && python3 "$DIR/unpatch-pvemanager.py" "$BUNDLE" || true
python3 - "$INDEX" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); s=p.read_text(encoding='utf-8')
s='\n'.join(x for x in s.splitlines() if 'windows-user-manager.js' not in x)+'\n'
s=re.sub(r'(&|&amp;)wum=[0-9.]+', '', s)
p.write_text(s,encoding='utf-8')
PY
rm -f "$TARGET_JS"
systemctl restart pveproxy
echo "PVE Windows User Manager removed."
