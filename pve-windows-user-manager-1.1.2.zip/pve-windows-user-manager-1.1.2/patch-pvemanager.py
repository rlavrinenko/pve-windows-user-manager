#!/usr/bin/env python3
from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: patch-pvemanager.py /usr/share/pve-manager/js/pvemanagerlib.js')

path = Path(sys.argv[1])
s = path.read_text(encoding='utf-8')

BEGIN = '/* PVE-WUM-NATIVE-BEGIN */'
END = '/* PVE-WUM-NATIVE-END */'

# Idempotent: remove an older native injection first.
s = re.sub(r'\n?[ \t]*/\* PVE-WUM-NATIVE-BEGIN \*/.*?/\* PVE-WUM-NATIVE-END \*/\n?', '\n', s, flags=re.S)

start = s.find("Ext.define('PVE.qemu.Config'")
if start < 0:
    start = s.find('Ext.define("PVE.qemu.Config"')
if start < 0:
    raise SystemExit('PVE.qemu.Config not found in pvemanagerlib.js')

call = s.find('me.callParent();', start)
if call < 0:
    raise SystemExit('PVE.qemu.Config initComponent callParent() not found')

# Ensure we are still inside the QEMU Config definition, not some later class.
next_class_single = s.find("\nExt.define('", start + 1)
next_class_double = s.find('\nExt.define("', start + 1)
next_classes = [x for x in (next_class_single, next_class_double) if x >= 0]
next_class = min(next_classes) if next_classes else len(s)
if call > next_class:
    raise SystemExit('refusing to patch: callParent() is outside PVE.qemu.Config')

line_start = s.rfind('\n', start, call) + 1
indent = s[line_start:call]
if indent.strip():
    raise SystemExit('refusing to patch: unexpected text before PVE.qemu.Config callParent()')

snippet = f'''{indent}{BEGIN}\n{indent}if (!template) {{\n{indent}    me.items.push({{\n{indent}        title: (PVE.WindowsUserManager && PVE.WindowsUserManager.title) ? PVE.WindowsUserManager.title() : 'Windows Users',\n{indent}        itemId: 'windows-users',\n{indent}        iconCls: 'fa fa-users',\n{indent}        xtype: 'panel',\n{indent}        border: false,\n{indent}        layout: 'fit',\n{indent}        html: '<div style="padding:20px"><h2>Windows Users</h2><div>Loading module...</div></div>',\n{indent}        listeners: {{\n{indent}            afterrender: function(panel) {{\n{indent}                try {{\n{indent}                    if (PVE.WindowsUserManager && PVE.WindowsUserManager.mountHost) {{\n{indent}                        PVE.WindowsUserManager.mountHost(panel, nodename, vmid);\n{indent}                    }} else {{\n{indent}                        panel.update('<div style="padding:20px"><h2>Windows Users</h2><div style="color:#a94442">windows-user-manager.js is not loaded</div></div>');\n{indent}                    }}\n{indent}                }} catch (e) {{\n{indent}                    panel.update('<div style="padding:20px"><h2>Windows Users</h2><pre style="white-space:pre-wrap">' + Ext.htmlEncode(e.stack || e.message || String(e)) + '</pre></div>');\n{indent}                }}\n{indent}            }},\n{indent}            activate: function(panel) {{\n{indent}                if (!panel._pveWumMounted && PVE.WindowsUserManager && PVE.WindowsUserManager.mountHost) {{\n{indent}                    PVE.WindowsUserManager.mountHost(panel, nodename, vmid);\n{indent}                }}\n{indent}            }},\n{indent}        }},\n{indent}    }});\n{indent}}}\n{indent}{END}\n\n'''

s = s[:line_start] + snippet + s[line_start:]
path.write_text(s, encoding='utf-8')

# Strong postconditions.
out = path.read_text(encoding='utf-8')
if out.count(BEGIN) != 1 or out.count(END) != 1:
    raise SystemExit('native marker verification failed')
block = out[start:next_class + len(snippet)]
if "itemId: 'windows-users'" not in block:
    raise SystemExit('Windows Users item not found inside PVE.qemu.Config after patch')
print('PVE.qemu.Config native Windows Users entry: OK')
