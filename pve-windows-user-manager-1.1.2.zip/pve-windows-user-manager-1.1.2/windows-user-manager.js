/*
 * PVE Windows User Manager
 * VM-level local Windows user management via QEMU Guest Agent only.
 * No WinRM, SSH, guest-side daemon or extra ports.
 */
(function () {
    'use strict';

    if (typeof Ext === 'undefined' || typeof PVE === 'undefined' || typeof Proxmox === 'undefined') {
        return;
    }

    const VERSION = '1.1.2';

    const i18n = {
        ru: {
            title: 'Windows Users', users: 'Локальные пользователи', refresh: 'Обновить', create: 'Создать', edit: 'Изменить',
            password: 'Пароль', enable: 'Включить', disable: 'Отключить', username: 'Пользователь', fullName: 'Полное имя',
            description: 'Описание', status: 'Статус', groups: 'Группы', sid: 'SID', enabled: 'Включен', disabled: 'Отключен',
            createTitle: 'Создать локального пользователя', editTitle: 'Карточка пользователя', passwordTitle: 'Изменить пароль',
            newPassword: 'Новый пароль', confirmPassword: 'Подтверждение пароля', save: 'Сохранить', cancel: 'Отмена',
            qgaRequired: 'QEMU Guest Agent недоступен. Включите QEMU Guest Agent в параметрах ВМ и установите qemu-guest-agent в Windows.',
            windowsOnly: 'Модуль доступен только для Windows ВМ.', loading: 'Загрузка пользователей и групп с ВМ…',
            noPermission: 'Нужна привилегия VM.GuestAgent.Unrestricted для этой ВМ.', error: 'Ошибка', success: 'Готово',
            selectUser: 'Выберите пользователя.', passwordsMismatch: 'Пароли не совпадают.', passwordRequired: 'Введите пароль.',
            usernameRequired: 'Введите имя пользователя.', confirmDisable: 'Отключить выбранного пользователя?', confirmEnable: 'Включить выбранного пользователя?',
            builtIn: 'Встроенная', ordinary: 'Локальная', type: 'Тип', agent: 'QEMU Guest Agent', version: 'Версия модуля',
            vmGroups: 'Локальные группы этой ВМ', search: 'Поиск', noUsers: 'Пользователи не найдены',
            deleteUser: 'Удалить', deleteTitle: 'Удаление пользователя', confirmDelete: 'Удалить локального пользователя «{0}»? Это действие нельзя отменить.',
            builtInDeleteBlocked: 'Встроенную системную учетную запись удалить нельзя.', advancedPassword: 'Расширенные параметры пароля',
            passwordRequiredOption: 'Пароль обязателен', passwordNeverExpires: 'Срок действия пароля не ограничен',
            userCannotChangePassword: 'Пользователь не может менять пароль', mustChangePassword: 'Сменить пароль при следующем входе',
            invalidPasswordOptions: 'Параметр «Сменить пароль при следующем входе» несовместим с «Срок действия пароля не ограничен» и «Пользователь не может менять пароль».',
        },
        uk: {
            title: 'Windows Users', users: 'Локальні користувачі', refresh: 'Оновити', create: 'Створити', edit: 'Змінити',
            password: 'Пароль', enable: 'Увімкнути', disable: 'Вимкнути', username: 'Користувач', fullName: 'Повне ім’я',
            description: 'Опис', status: 'Статус', groups: 'Групи', sid: 'SID', enabled: 'Увімкнений', disabled: 'Вимкнений',
            createTitle: 'Створити локального користувача', editTitle: 'Картка користувача', passwordTitle: 'Змінити пароль',
            newPassword: 'Новий пароль', confirmPassword: 'Підтвердження пароля', save: 'Зберегти', cancel: 'Скасувати',
            qgaRequired: 'QEMU Guest Agent недоступний. Увімкніть QEMU Guest Agent у параметрах ВМ і встановіть qemu-guest-agent у Windows.',
            windowsOnly: 'Модуль доступний лише для Windows ВМ.', loading: 'Завантаження користувачів і груп з ВМ…',
            noPermission: 'Потрібен привілей VM.GuestAgent.Unrestricted для цієї ВМ.', error: 'Помилка', success: 'Готово',
            selectUser: 'Оберіть користувача.', passwordsMismatch: 'Паролі не збігаються.', passwordRequired: 'Введіть пароль.',
            usernameRequired: 'Введіть ім’я користувача.', confirmDisable: 'Вимкнути обраного користувача?', confirmEnable: 'Увімкнути обраного користувача?',
            builtIn: 'Вбудований', ordinary: 'Локальний', type: 'Тип', agent: 'QEMU Guest Agent', version: 'Версія модуля',
            vmGroups: 'Локальні групи цієї ВМ', search: 'Пошук', noUsers: 'Користувачів не знайдено',
            deleteUser: 'Видалити', deleteTitle: 'Видалення користувача', confirmDelete: 'Видалити локального користувача «{0}»? Цю дію неможливо скасувати.',
            builtInDeleteBlocked: 'Вбудований системний обліковий запис видалити не можна.', advancedPassword: 'Розширені параметри пароля',
            passwordRequiredOption: 'Пароль обов’язковий', passwordNeverExpires: 'Термін дії пароля не обмежений',
            userCannotChangePassword: 'Користувач не може змінювати пароль', mustChangePassword: 'Змінити пароль під час наступного входу',
            invalidPasswordOptions: 'Параметр «Змінити пароль під час наступного входу» несумісний з «Термін дії пароля не обмежений» і «Користувач не може змінювати пароль».',
        },
        en: {
            title: 'Windows Users', users: 'Local users', refresh: 'Refresh', create: 'Create', edit: 'Edit',
            password: 'Password', enable: 'Enable', disable: 'Disable', username: 'User', fullName: 'Full name',
            description: 'Description', status: 'Status', groups: 'Groups', sid: 'SID', enabled: 'Enabled', disabled: 'Disabled',
            createTitle: 'Create local user', editTitle: 'User card', passwordTitle: 'Change password',
            newPassword: 'New password', confirmPassword: 'Confirm password', save: 'Save', cancel: 'Cancel',
            qgaRequired: 'QEMU Guest Agent is unavailable. Enable QEMU Guest Agent in VM options and install qemu-guest-agent in Windows.',
            windowsOnly: 'This module is available only for Windows VMs.', loading: 'Loading users and groups from the VM…',
            noPermission: 'VM.GuestAgent.Unrestricted privilege is required for this VM.', error: 'Error', success: 'Done',
            selectUser: 'Select a user.', passwordsMismatch: 'Passwords do not match.', passwordRequired: 'Enter a password.',
            usernameRequired: 'Enter a username.', confirmDisable: 'Disable selected user?', confirmEnable: 'Enable selected user?',
            builtIn: 'Built-in', ordinary: 'Local', type: 'Type', agent: 'QEMU Guest Agent', version: 'Module version',
            vmGroups: 'Local groups on this VM', search: 'Search', noUsers: 'No users found',
            deleteUser: 'Delete', deleteTitle: 'Delete user', confirmDelete: 'Delete local user “{0}”? This action cannot be undone.',
            builtInDeleteBlocked: 'Built-in system accounts cannot be deleted.', advancedPassword: 'Advanced password options',
            passwordRequiredOption: 'Password is required', passwordNeverExpires: 'Password never expires',
            userCannotChangePassword: 'User cannot change password', mustChangePassword: 'User must change password at next logon',
            invalidPasswordOptions: '“User must change password at next logon” cannot be combined with “Password never expires” or “User cannot change password”.',
        },
    };

    function lang() {
        let l = (Proxmox.defaultLang || 'en').toLowerCase();
        if (l.startsWith('ru')) return 'ru';
        if (l.startsWith('uk') || l.startsWith('ua')) return 'uk';
        return 'en';
    }

    function t(key) {
        return i18n[lang()][key] || i18n.en[key] || key;
    }

    function utf8ToB64(str) {
        if (window.TextEncoder) {
            const bytes = new TextEncoder().encode(str);
            let s = '';
            const chunk = 0x8000;
            for (let i = 0; i < bytes.length; i += chunk) {
                s += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunk, bytes.length)));
            }
            return btoa(s);
        }
        return btoa(unescape(encodeURIComponent(str)));
    }

    function b64ToUtf8(b64) {
        const bin = atob(b64);
        if (window.TextDecoder) {
            const bytes = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
            return new TextDecoder('utf-8').decode(bytes);
        }
        return decodeURIComponent(escape(bin));
    }

    function psEncodedCommand(script) {
        const bytes = new Uint8Array(script.length * 2);
        for (let i = 0; i < script.length; i++) {
            const c = script.charCodeAt(i);
            bytes[i * 2] = c & 0xff;
            bytes[i * 2 + 1] = c >> 8;
        }
        let s = '';
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
            s += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunk, bytes.length)));
        }
        return btoa(s);
    }

    function apiRequest(opts) {
        return new Promise((resolve, reject) => {
            Ext.Ajax.request({
                url: opts.url,
                method: opts.method || 'GET',
                jsonData: opts.jsonData,
                params: opts.params,
                timeout: opts.timeout || 60000,
                headers: opts.method && opts.method !== 'GET' ? {
                    CSRFPreventionToken: Proxmox.CSRFPreventionToken,
                } : undefined,
                success: function (response) {
                    try {
                        const obj = Ext.decode(response.responseText);
                        resolve(obj.data);
                    } catch (e) {
                        reject(new Error('Invalid API response'));
                    }
                },
                failure: function (response) {
                    let msg = response.statusText || 'API error';
                    try {
                        const obj = Ext.decode(response.responseText);
                        if (obj && obj.errors) {
                            msg = Object.keys(obj.errors).map(k => `${k}: ${obj.errors[k]}`).join('\n');
                        } else if (obj && obj.message) {
                            msg = obj.message;
                        }
                    } catch (e) {
                        if (response.responseText) msg = response.responseText;
                    }
                    const err = new Error(msg);
                    err.status = response.status;
                    err.responseText = response.responseText;
                    reject(err);
                },
            });
        });
    }

    function isLegacyArrayError(err) {
        const s = String((err && (err.message + ' ' + err.responseText)) || '').toLowerCase();
        return s.includes('command') && (s.includes('array') || s.includes('schema') || s.includes('property'));
    }

    const PS_BASE = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding

function Write-PveResult([object]$obj) {
    $json = $obj | ConvertTo-Json -Depth 12 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    [Console]::Out.WriteLine('PVEWUM:' + [Convert]::ToBase64String($bytes))
}

function Get-SidValue([object]$entry) {
    try {
        $raw = $entry.psbase.Properties['objectSid'].Value
        if ($null -eq $raw) { return $null }
        return (New-Object System.Security.Principal.SecurityIdentifier($raw, 0)).Value
    } catch { return $null }
}

function Get-Prop([object]$entry, [string]$name, $default = $null) {
    try {
        $v = $entry.psbase.Properties[$name].Value
        if ($null -eq $v) { return $default }
        return $v
    } catch { return $default }
}

function Set-UserPasswordOptions([object]$user, [object]$opts) {
    # WinNT provider / USER_INFO flags. Keep every unrelated flag intact.
    # 0x20   UF_PASSWD_NOTREQD
    # 0x40   UF_PASSWD_CANT_CHANGE
    # 0x10000 UF_DONT_EXPIRE_PASSWD
    # 0x800000 UF_PASSWORD_EXPIRED
    $flags = [int](Get-Prop $user 'UserFlags' 0)

    if ($null -ne $opts.passwordRequired) {
        if ([bool]$opts.passwordRequired) { $flags = $flags -band (-bnot 0x20) }
        else { $flags = $flags -bor 0x20 }
    }
    if ($null -ne $opts.userCannotChangePassword) {
        if ([bool]$opts.userCannotChangePassword) { $flags = $flags -bor 0x40 }
        else { $flags = $flags -band (-bnot 0x40) }
    }
    if ($null -ne $opts.passwordNeverExpires) {
        if ([bool]$opts.passwordNeverExpires) { $flags = $flags -bor 0x10000 }
        else { $flags = $flags -band (-bnot 0x10000) }
    }
    if ($null -ne $opts.mustChangePassword) {
        if ([bool]$opts.mustChangePassword) { $flags = $flags -bor 0x800000 }
        else { $flags = $flags -band (-bnot 0x800000) }
    }

    $user.Put('UserFlags', $flags)
    if ($null -ne $opts.mustChangePassword) {
        try { $user.Put('PasswordExpired', $(if ([bool]$opts.mustChangePassword) { 1 } else { 0 })) } catch {}
    }
    $user.SetInfo()
}

function Find-EntryBySid([object]$computer, [string]$sid, [string]$className) {
    foreach ($c in @($computer.psbase.Children)) {
        if ($c.SchemaClassName -ne $className) { continue }
        if ((Get-SidValue $c) -eq $sid) { return $c }
    }
    throw "$className SID $sid not found"
}

function Get-GroupMembers([object]$group) {
    $result = @()
    try {
        foreach ($m in @($group.psbase.Invoke('Members'))) {
            try {
                $type = $m.GetType()
                $name = $type.InvokeMember('Name', 'GetProperty', $null, $m, $null)
                $cls = $type.InvokeMember('Class', 'GetProperty', $null, $m, $null)
                $path = $type.InvokeMember('ADsPath', 'GetProperty', $null, $m, $null)
                $sid = $null
                try { $sid = Get-SidValue ([ADSI]$path) } catch {}
                $result += [pscustomobject]@{ name = [string]$name; class = [string]$cls; path = [string]$path; sid = $sid }
            } catch {}
        }
    } catch {}
    return @($result)
}

function Read-State([object]$computer) {
    $groups = @()
    $users = @()
    $groupMembersBySid = @{}

    foreach ($c in @($computer.psbase.Children)) {
        if ($c.SchemaClassName -eq 'Group') {
            $sid = Get-SidValue $c
            $members = @(Get-GroupMembers $c)
            $groupMembersBySid[$sid] = $members
            $groups += [pscustomobject]@{
                name = [string](Get-Prop $c 'Name' '')
                description = [string](Get-Prop $c 'Description' '')
                sid = $sid
                members = $members
            }
        }
    }

    foreach ($c in @($computer.psbase.Children)) {
        if ($c.SchemaClassName -ne 'User') { continue }
        $sid = Get-SidValue $c
        $flags = [int](Get-Prop $c 'UserFlags' 0)
        $userGroups = @()
        foreach ($g in $groups) {
            foreach ($m in @($groupMembersBySid[$g.sid])) {
                if (($m.sid -and $m.sid -eq $sid) -or (!$m.sid -and $m.name -eq [string](Get-Prop $c 'Name' ''))) {
                    $userGroups += [pscustomobject]@{ name = $g.name; sid = $g.sid }
                    break
                }
            }
        }
        $rid = $null
        if ($sid -match '-(\d+)$') { $rid = [int]$Matches[1] }
        $users += [pscustomobject]@{
            name = [string](Get-Prop $c 'Name' '')
            fullName = [string](Get-Prop $c 'FullName' '')
            description = [string](Get-Prop $c 'Description' '')
            sid = $sid
            enabled = (($flags -band 2) -eq 0)
            userFlags = $flags
            passwordRequired = (($flags -band 0x20) -eq 0)
            userCannotChangePassword = (($flags -band 0x40) -ne 0)
            passwordNeverExpires = (($flags -band 0x10000) -ne 0)
            mustChangePassword = (([int](Get-Prop $c 'PasswordExpired' 0) -ne 0) -or (($flags -band 0x800000) -ne 0))
            builtIn = ($rid -in @(500,501,503,504))
            groups = @($userGroups)
        }
    }

    return [pscustomobject]@{
        computer = $env:COMPUTERNAME
        users = @($users | Sort-Object name)
        groups = @($groups | Sort-Object name)
    }
}

try {
    $payloadJson = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__PAYLOAD__'))
    $p = $payloadJson | ConvertFrom-Json
    $computer = [ADSI]("WinNT://" + $env:COMPUTERNAME + ",computer")

    switch ([string]$p.op) {
        'list' {
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'create' {
            if ([string]::IsNullOrWhiteSpace([string]$p.username)) { throw 'Username is required' }
            if ([string]::IsNullOrEmpty([string]$p.password)) { throw 'Password is required' }
            $u = $computer.psbase.Children.Add([string]$p.username, 'user')
            $u.psbase.Invoke('SetPassword', [string]$p.password)
            if ($null -ne $p.fullName) { $u.Put('FullName', [string]$p.fullName) }
            if ($null -ne $p.description) { $u.Put('Description', [string]$p.description) }
            $u.SetInfo()
            $u = [ADSI]("WinNT://" + $env:COMPUTERNAME + "/" + [string]$p.username + ",user")
            Set-UserPasswordOptions $u $p
            foreach ($gsid in @($p.groups)) {
                if ([string]::IsNullOrWhiteSpace([string]$gsid)) { continue }
                $g = Find-EntryBySid $computer ([string]$gsid) 'Group'
                try { $g.psbase.Invoke('Add', $u.Path) } catch {
                    if ($_.Exception.Message -notmatch 'already') { throw }
                }
            }
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'update' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            if ($null -ne $p.fullName) { $u.Put('FullName', [string]$p.fullName) }
            if ($null -ne $p.description) { $u.Put('Description', [string]$p.description) }
            Set-UserPasswordOptions $u $p

            $wanted = @{}
            foreach ($gsid in @($p.groups)) { if ($gsid) { $wanted[[string]$gsid] = $true } }
            foreach ($g in @($computer.psbase.Children)) {
                if ($g.SchemaClassName -ne 'Group') { continue }
                $gsid = Get-SidValue $g
                if (!$gsid) { continue }
                $isMember = $false
                foreach ($m in @(Get-GroupMembers $g)) {
                    if ($m.sid -eq [string]$p.sid) { $isMember = $true; break }
                }
                if ($wanted.ContainsKey($gsid) -and !$isMember) {
                    $g.psbase.Invoke('Add', $u.Path)
                } elseif (!$wanted.ContainsKey($gsid) -and $isMember) {
                    $g.psbase.Invoke('Remove', $u.Path)
                }
            }
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'enabled' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            $flags = [int](Get-Prop $u 'UserFlags' 0)
            if ([bool]$p.enabled) { $flags = $flags -band (-bnot 2) } else { $flags = $flags -bor 2 }
            $u.Put('UserFlags', $flags)
            $u.SetInfo()
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'password' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            if ([string]::IsNullOrEmpty([string]$p.password)) { throw 'Password is required' }
            $u.psbase.Invoke('SetPassword', [string]$p.password)
            Set-UserPasswordOptions $u $p
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        'delete' {
            $u = Find-EntryBySid $computer ([string]$p.sid) 'User'
            $usid = Get-SidValue $u
            $rid = $null
            if ($usid -match '-(\d+)$') { $rid = [int]$Matches[1] }
            if ($rid -in @(500,501,503,504)) { throw 'Built-in system accounts cannot be deleted' }
            $computer.psbase.Children.Remove($u)
            Write-PveResult ([pscustomobject]@{ ok = $true; data = (Read-State $computer) })
        }
        default { throw ('Unknown operation: ' + [string]$p.op) }
    }
} catch {
    Write-PveResult ([pscustomobject]@{ ok = $false; error = $_.Exception.Message })
}
`;

    const WUM = {
        version: VERSION,

        baseUrl(node, vmid) {
            return `/api2/json/nodes/${encodeURIComponent(node)}/qemu/${encodeURIComponent(vmid)}`;
        },

        async osInfo(node, vmid) {
            return apiRequest({ url: this.baseUrl(node, vmid) + '/agent/get-osinfo', method: 'GET', timeout: 10000 });
        },

        buildCommand(payload) {
            const payload64 = utf8ToB64(Ext.encode(payload));
            const script = PS_BASE.replace('__PAYLOAD__', payload64);
            return [
                'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
                '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', psEncodedCommand(script),
            ];
        },

        async pveMajor() {
            if (this._pveMajor) return this._pveMajor;
            try {
                const v = await apiRequest({ url: '/api2/json/version', method: 'GET', timeout: 10000 });
                const raw = String((v && (v.version || v.release)) || '');
                const m = raw.match(/^(\d+)/);
                this._pveMajor = m ? parseInt(m[1], 10) : 7;
            } catch (e) {
                // Oldest supported UI is PVE 7; use its conservative transport if version lookup fails.
                this._pveMajor = 7;
            }
            return this._pveMajor;
        },

        async exec(node, vmid, payload) {
            const url = this.baseUrl(node, vmid) + '/agent/exec';
            const cmd = this.buildCommand(payload);
            const major = await this.pveMajor();
            let data;

            if (major < 8) {
                // PVE 7 API schema uses string-alist. A NUL-separated list is parsed by split_list().
                data = await apiRequest({ url, method: 'POST', params: { command: cmd.join('\u0000') }, timeout: 30000 });
            } else {
                // PVE 8/9 API schema uses an array. ExtJS serializes an array as repeated form parameters.
                try {
                    data = await apiRequest({ url, method: 'POST', params: { command: cmd }, timeout: 30000 });
                } catch (e) {
                    // Some mixed-version clusters can proxy to an older node. Retry the PVE 7 representation.
                    data = await apiRequest({ url, method: 'POST', params: { command: cmd.join('\u0000') }, timeout: 30000 });
                }
            }

            if (!data || data.pid === undefined) throw new Error('QEMU Guest Agent did not return a PID');
            return this.wait(node, vmid, data.pid);
        },

        async wait(node, vmid, pid) {
            const url = this.baseUrl(node, vmid) + '/agent/exec-status';
            const started = Date.now();
            while (Date.now() - started < 90000) {
                const s = await apiRequest({ url, method: 'GET', params: { pid }, timeout: 15000 });
                if (s && s.exited) {
                    const out = s['out-data'] || '';
                    const lines = String(out).split(/\r?\n/).reverse();
                    const marker = lines.find(x => x.indexOf('PVEWUM:') === 0);
                    if (!marker) {
                        const err = s['err-data'] || `PowerShell exited with code ${s.exitcode}`;
                        throw new Error(err || 'No result returned by Windows');
                    }
                    let result;
                    try { result = Ext.decode(b64ToUtf8(marker.substring(7))); } catch (e) { throw new Error('Cannot decode Windows response'); }
                    if (!result.ok) throw new Error(result.error || 'Windows operation failed');
                    return result;
                }
                await new Promise(resolve => Ext.defer(resolve, 300));
            }
            throw new Error('QEMU Guest Agent command timeout');
        },
    };

    PVE.WindowsUserManager = WUM;

    function groupItems(groups, selected) {
        const sel = {};
        (selected || []).forEach(g => sel[g.sid || g] = true);
        return (groups || []).map(g => ({
            boxLabel: Ext.htmlEncode(g.name),
            name: 'group_' + g.sid,
            inputValue: g.sid,
            checked: !!sel[g.sid],
            margin: '0 18 6 0',
        }));
    }

    function selectedGroups(form, groups) {
        const vals = form.getValues();
        return (groups || []).filter(g => {
            const v = vals['group_' + g.sid];
            return v === true || v === 'on' || v === g.sid || (Array.isArray(v) && v.length);
        }).map(g => g.sid);
    }

    function passwordOptionsFromForm(form, defaults) {
        defaults = defaults || {};
        function checked(name, fallback) {
            var field = form.findField(name);
            return field ? !!field.getValue() : !!fallback;
        }
        return {
            passwordRequired: checked('passwordRequired', defaults.passwordRequired !== false),
            passwordNeverExpires: checked('passwordNeverExpires', !!defaults.passwordNeverExpires),
            userCannotChangePassword: checked('userCannotChangePassword', !!defaults.userCannotChangePassword),
            mustChangePassword: checked('mustChangePassword', !!defaults.mustChangePassword),
        };
    }

    function validatePasswordOptions(opts) {
        if (opts.mustChangePassword && (opts.passwordNeverExpires || opts.userCannotChangePassword)) {
            Ext.Msg.alert(t('error'), t('invalidPasswordOptions'));
            return false;
        }
        return true;
    }

    function advancedPasswordItems(user) {
        user = user || {};
        return [
            { xtype: 'displayfield', value: '<b>' + Ext.htmlEncode(t('advancedPassword')) + '</b>', margin: '12 0 6 0' },
            { xtype: 'checkbox', boxLabel: t('passwordRequiredOption'), name: 'passwordRequired', checked: user.passwordRequired !== false },
            { xtype: 'checkbox', boxLabel: t('passwordNeverExpires'), name: 'passwordNeverExpires', checked: !!user.passwordNeverExpires },
            { xtype: 'checkbox', boxLabel: t('userCannotChangePassword'), name: 'userCannotChangePassword', checked: !!user.userCannotChangePassword },
            { xtype: 'checkbox', boxLabel: t('mustChangePassword'), name: 'mustChangePassword', checked: !!user.mustChangePassword },
        ];
    }

    WUM.openCreate = function (manager) {
        var form = Ext.create('Ext.form.Panel', {
            bodyPadding: 14,
            border: false,
            autoScroll: true,
            defaults: { anchor: '100%', labelWidth: 150 },
            items: [
                { xtype: 'textfield', fieldLabel: t('username'), name: 'username', allowBlank: false, maxLength: 64 },
                { xtype: 'textfield', fieldLabel: t('fullName'), name: 'fullName', maxLength: 256 },
                { xtype: 'textarea', fieldLabel: t('description'), name: 'description', height: 90, maxLength: 1024 },
                { xtype: 'textfield', inputType: 'password', fieldLabel: t('newPassword'), name: 'password', allowBlank: false },
                { xtype: 'textfield', inputType: 'password', fieldLabel: t('confirmPassword'), name: 'confirm', allowBlank: false },
            ].concat(advancedPasswordItems({ passwordRequired: true })).concat([
                { xtype: 'displayfield', value: '<b>' + Ext.htmlEncode(t('vmGroups')) + '</b>', margin: '10 0 8 0' },
                { xtype: 'checkboxgroup', columns: 2, vertical: true, items: groupItems(manager.groups, []) },
            ]),
        });
        var win = Ext.create('Ext.window.Window', {
            modal: true,
            width: 620,
            height: 610,
            layout: 'fit',
            title: t('createTitle'),
            items: [form],
            buttons: [
                { text: t('save'), iconCls: 'fa fa-check', handler: async function () {
                    if (!form.getForm().isValid()) return;
                    var v = form.getForm().getValues();
                    if (!v.username) return Ext.Msg.alert(t('error'), t('usernameRequired'));
                    if (!v.password) return Ext.Msg.alert(t('error'), t('passwordRequired'));
                    if (v.password !== v.confirm) return Ext.Msg.alert(t('error'), t('passwordsMismatch'));
                    var passwordOpts = passwordOptionsFromForm(form.getForm(), { passwordRequired: true });
                    if (!validatePasswordOptions(passwordOpts)) return;
                    var btn = this; btn.setDisabled(true); win.setLoading(true);
                    try {
                        var r = await WUM.exec(manager.node, manager.vmid, Ext.apply({
                            op: 'create', username: v.username, fullName: v.fullName || '', description: v.description || '',
                            password: v.password, groups: selectedGroups(form.getForm(), manager.groups),
                        }, passwordOpts));
                        manager.loadState(r.data); win.close();
                    } catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message || String(e))); }
                    finally { if (!win.destroyed) { win.setLoading(false); btn.setDisabled(false); } }
                }},
                { text: t('cancel'), handler: function () { win.close(); } },
            ],
        });
        win.show();
    };

    WUM.openEdit = function (manager, user) {
        var form = Ext.create('Ext.form.Panel', {
            bodyPadding: 14, border: false, autoScroll: true,
            defaults: { anchor: '100%', labelWidth: 150 },
            items: [
                { xtype: 'displayfield', fieldLabel: t('username'), value: Ext.htmlEncode(user.name) },
                { xtype: 'displayfield', fieldLabel: t('sid'), value: Ext.htmlEncode(user.sid || '') },
                { xtype: 'textfield', fieldLabel: t('fullName'), name: 'fullName', value: user.fullName || '', maxLength: 256 },
                { xtype: 'textarea', fieldLabel: t('description'), name: 'description', value: user.description || '', height: 100, maxLength: 1024 },
            ].concat(advancedPasswordItems(user)).concat([
                { xtype: 'displayfield', value: '<b>' + Ext.htmlEncode(t('vmGroups')) + '</b>', margin: '10 0 8 0' },
                { xtype: 'checkboxgroup', columns: 2, vertical: true, items: groupItems(manager.groups, user.groups || []) },
            ]),
        });
        var win = Ext.create('Ext.window.Window', {
            modal: true, width: 640, height: 560, layout: 'fit', title: t('editTitle'), items: [form],
            buttons: [
                { text: t('save'), iconCls: 'fa fa-check', handler: async function () {
                    var btn = this; btn.setDisabled(true); win.setLoading(true);
                    var v = form.getForm().getValues();
                    var passwordOpts = passwordOptionsFromForm(form.getForm(), user);
                    if (!validatePasswordOptions(passwordOpts)) { btn.setDisabled(false); win.setLoading(false); return; }
                    try {
                        var r = await WUM.exec(manager.node, manager.vmid, Ext.apply({
                            op: 'update', sid: user.sid, fullName: v.fullName || '', description: v.description || '',
                            groups: selectedGroups(form.getForm(), manager.groups),
                        }, passwordOpts));
                        manager.loadState(r.data); win.close();
                    } catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message || String(e))); }
                    finally { if (!win.destroyed) { win.setLoading(false); btn.setDisabled(false); } }
                }},
                { text: t('cancel'), handler: function () { win.close(); } },
            ],
        });
        win.show();
    };

    WUM.openPassword = function (manager, user) {
        var form = Ext.create('Ext.form.Panel', {
            bodyPadding: 14, border: false, defaults: { anchor: '100%', labelWidth: 160 },
            items: [
                { xtype: 'displayfield', fieldLabel: t('username'), value: Ext.htmlEncode(user.name) },
                { xtype: 'textfield', inputType: 'password', fieldLabel: t('newPassword'), name: 'password', allowBlank: false },
                { xtype: 'textfield', inputType: 'password', fieldLabel: t('confirmPassword'), name: 'confirm', allowBlank: false },
            ].concat(advancedPasswordItems(user)),
        });
        var win = Ext.create('Ext.window.Window', {
            modal: true, width: 520, height: 390, layout: 'fit', title: t('passwordTitle'), items: [form],
            buttons: [
                { text: t('save'), iconCls: 'fa fa-key', handler: async function () {
                    if (!form.getForm().isValid()) return;
                    var v = form.getForm().getValues();
                    if (v.password !== v.confirm) return Ext.Msg.alert(t('error'), t('passwordsMismatch'));
                    var passwordOpts = passwordOptionsFromForm(form.getForm(), user);
                    if (!validatePasswordOptions(passwordOpts)) return;
                    var btn = this; btn.setDisabled(true); win.setLoading(true);
                    try { var r = await WUM.exec(manager.node, manager.vmid, Ext.apply({ op: 'password', sid: user.sid, password: v.password }, passwordOpts)); win.close(); manager.loadState(r.data); }
                    catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message || String(e))); }
                    finally { if (!win.destroyed) { win.setLoading(false); btn.setDisabled(false); } }
                }},
                { text: t('cancel'), handler: function () { win.close(); } },
            ],
        });
        win.show();
    };

    WUM.createManager = function (node, vmid) {
        var manager = Ext.create('Ext.panel.Panel', {
            layout: 'fit', border: false,
        });
        manager.node = node;
        manager.vmid = vmid;
        manager.groups = [];

        manager.store = Ext.create('Ext.data.Store', {
            fields: ['name', 'fullName', 'description', 'sid', 'enabled', 'builtIn', 'groups',
                'passwordRequired', 'passwordNeverExpires', 'userCannotChangePassword', 'mustChangePassword'],
            data: [], sorters: [{ property: 'name', direction: 'ASC' }],
        });

        manager.loadState = function (state) {
            if (!state || !manager.store) return;
            manager.groups = state.groups || [];
            manager.store.loadData(state.users || []);
        };
        manager.updateButtons = function () {
            var r = manager.grid.getSelectionModel().getSelection()[0];
            ['editBtn', 'passwordBtn', 'toggleBtn'].forEach(function (id) {
                var b = manager.grid.down('#' + id); if (b) b.setDisabled(!r);
            });
            var del = manager.grid.down('#deleteBtn');
            if (del) del.setDisabled(!r || !!r.get('builtIn'));
            if (r) {
                var b = manager.grid.down('#toggleBtn');
                if (b) { b.setText(r.get('enabled') ? t('disable') : t('enable')); b.setIconCls(r.get('enabled') ? 'fa fa-ban' : 'fa fa-check'); }
            }
        };
        manager.reload = async function () {
            manager.setLoading(t('loading'));
            try {
                var os;
                try { os = await WUM.osInfo(manager.node, manager.vmid); }
                catch (e) {
                    if (String(e.message).indexOf('permission') !== -1 || String(e.message).indexOf('403') !== -1) throw new Error(t('noPermission'));
                    throw new Error(t('qgaRequired'));
                }
                var info = os && os.result ? os.result : os;
                var id = String((info && (info.id || info.name || info['pretty-name'])) || '').toLowerCase();
                if (id && id.indexOf('windows') === -1 && id.indexOf('microsoft') === -1) throw new Error(t('windowsOnly'));
                var r = await WUM.exec(manager.node, manager.vmid, { op: 'list' });
                manager.loadState(r.data);
            } catch (e) {
                manager.store.removeAll();
                Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message || String(e)));
            } finally {
                manager.setLoading(false); manager.updateButtons();
            }
        };
        manager.createUser = function () { WUM.openCreate(manager); };
        manager.editUser = function () {
            var r = manager.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            WUM.openEdit(manager, Ext.clone(r.data));
        };
        manager.passwordUser = function () {
            var r = manager.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            WUM.openPassword(manager, Ext.clone(r.data));
        };
        manager.toggleUser = function () {
            var r = manager.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            var target = !r.get('enabled');
            Ext.Msg.confirm(target ? t('enable') : t('disable'), target ? t('confirmEnable') : t('confirmDisable'), async function (ans) {
                if (ans !== 'yes') return;
                manager.setLoading(true);
                try {
                    var res = await WUM.exec(manager.node, manager.vmid, { op: 'enabled', sid: r.get('sid'), enabled: target });
                    manager.loadState(res.data);
                } catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message || String(e))); }
                finally { manager.setLoading(false); manager.updateButtons(); }
            });
        };

        manager.deleteUser = function () {
            var r = manager.grid.getSelectionModel().getSelection()[0];
            if (!r) return Ext.Msg.alert(t('error'), t('selectUser'));
            if (r.get('builtIn')) return Ext.Msg.alert(t('error'), t('builtInDeleteBlocked'));
            var msg = Ext.String.format(t('confirmDelete'), Ext.htmlEncode(r.get('name')));
            Ext.Msg.confirm(t('deleteTitle'), msg, async function (ans) {
                if (ans !== 'yes') return;
                manager.setLoading(true);
                try {
                    var res = await WUM.exec(manager.node, manager.vmid, { op: 'delete', sid: r.get('sid') });
                    manager.loadState(res.data);
                } catch (e) { Ext.Msg.alert(t('error'), Ext.htmlEncode(e.message || String(e))); }
                finally { manager.setLoading(false); manager.updateButtons(); }
            });
        };

        manager.grid = Ext.create('Ext.grid.Panel', {
            store: manager.store, border: false,
            viewConfig: { emptyText: t('noUsers'), deferEmptyText: false },
            columns: [
                { text: t('username'), dataIndex: 'name', width: 180, renderer: Ext.htmlEncode },
                { text: t('fullName'), dataIndex: 'fullName', width: 200, renderer: Ext.htmlEncode },
                { text: t('status'), dataIndex: 'enabled', width: 105, renderer: function (v) {
                    return v ? '<span style="color:#3b8b3b"><i class="fa fa-check-circle"></i> ' + t('enabled') + '</span>' :
                        '<span style="color:#a94442"><i class="fa fa-ban"></i> ' + t('disabled') + '</span>';
                }},
                { text: t('type'), dataIndex: 'builtIn', width: 105, renderer: function (v) { return v ? t('builtIn') : t('ordinary'); } },
                { text: t('description'), dataIndex: 'description', flex: 1, minWidth: 220, renderer: function (v) { return Ext.htmlEncode(v || ''); } },
                { text: t('groups'), dataIndex: 'groups', width: 300, renderer: function (v) { return (v || []).map(function (g) { return Ext.htmlEncode(g.name); }).join(', '); } },
                { text: t('sid'), dataIndex: 'sid', width: 250, hidden: true, renderer: Ext.htmlEncode },
            ],
            listeners: {
                itemdblclick: function () { manager.editUser(); },
                selectionchange: function () { manager.updateButtons(); },
            },
            tbar: [
                { text: t('refresh'), iconCls: 'fa fa-refresh', handler: function () { manager.reload(); } },
                { itemId: 'createBtn', text: t('create'), iconCls: 'fa fa-user-plus', handler: function () { manager.createUser(); } },
                { itemId: 'editBtn', text: t('edit'), iconCls: 'fa fa-pencil', disabled: true, handler: function () { manager.editUser(); } },
                { itemId: 'passwordBtn', text: t('password'), iconCls: 'fa fa-key', disabled: true, handler: function () { manager.passwordUser(); } },
                '-',
                { itemId: 'toggleBtn', text: t('disable'), iconCls: 'fa fa-ban', disabled: true, handler: function () { manager.toggleUser(); } },
                { itemId: 'deleteBtn', text: t('deleteUser'), iconCls: 'fa fa-trash', disabled: true, handler: function () { manager.deleteUser(); } },
                '->',
                { xtype: 'textfield', width: 240, emptyText: t('search'), enableKeyEvents: true, listeners: { change: function (f, v) {
                    manager.store.clearFilter(); if (!v) return; var q = String(v).toLowerCase();
                    manager.store.filterBy(function (r) {
                        return [r.get('name'), r.get('fullName'), r.get('description')]
                            .concat((r.get('groups') || []).map(function (g) { return g.name; }))
                            .join(' ').toLowerCase().indexOf(q) !== -1;
                    });
                }}},
            ],
        });
        manager.add(manager.grid);
        Ext.defer(function () { if (!manager.destroyed) manager.reload(); }, 20);
        return manager;
    };

    // The navigation entry itself is injected natively into PVE.qemu.Config by
    // install.sh.  It is a stock Ext.panel.Panel, so card switching uses only
    // Proxmox's own ConfigPanel implementation.  This function mounts the real
    // manager inside that already-active stock card and keeps any construction
    // error visible inside Windows Users instead of leaving the previous card.
    WUM.title = function () {
        return t('title');
    };

    WUM.mountHost = function (host, node, vmid) {
        if (!host || host.destroyed || host._pveWumMounted) return;
        host._pveWumMounted = true;

        try {
            host.removeAll(true);
            host.setLoading(t('loading'));
            var manager = WUM.createManager(node, vmid);
            host.add(manager);
            host.updateLayout();
            host.setLoading(false);
        } catch (e) {
            host._pveWumMounted = false;
            try { host.setLoading(false); } catch (_) {}
            var msg = (e && e.message ? e.message + '\n\n' : '') + (e && e.stack ? e.stack : String(e));
            if (window.console && console.error) console.error('PVE Windows User Manager mount:', e);
            try { host.removeAll(true); } catch (_) {}
            host.update(
                '<div style="padding:20px">' +
                '<h2 style="margin-top:0">Windows Users</h2>' +
                '<div style="color:#a94442;font-weight:600;margin-bottom:10px">Module initialization error</div>' +
                '<pre style="white-space:pre-wrap;user-select:text">' + Ext.htmlEncode(msg) + '</pre>' +
                '<div>Module ' + VERSION + '</div></div>'
            );
        }
    };
})();
