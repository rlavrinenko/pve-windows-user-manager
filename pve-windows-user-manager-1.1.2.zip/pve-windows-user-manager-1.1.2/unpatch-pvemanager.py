#!/usr/bin/env python3
from pathlib import Path
import re, sys
if len(sys.argv) != 2:
    raise SystemExit('usage: unpatch-pvemanager.py FILE')
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
s2=re.sub(r'\n?[ \t]*/\* PVE-WUM-NATIVE-BEGIN \*/.*?/\* PVE-WUM-NATIVE-END \*/\n?', '\n', s, flags=re.S)
p.write_text(s2, encoding='utf-8')
print('native Windows Users entry removed')
