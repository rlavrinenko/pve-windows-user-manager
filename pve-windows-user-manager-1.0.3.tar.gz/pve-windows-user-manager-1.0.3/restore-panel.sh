#!/usr/bin/env bash
set -euo pipefail
# Emergency UI recovery: remove only PVE-WUM injection and its old persistence hook.
INDEX="/usr/share/pve-manager/index.html.tpl"
rm -f /etc/apt/apt.conf.d/99-pve-windows-user-manager /usr/local/sbin/pve-wum-repair
rm -rf /usr/local/share/pve-windows-user-manager
if [[ -f "$INDEX" ]]; then
  sed -i '/windows-user-manager\.js/d' "$INDEX"
fi
rm -f /usr/share/pve-manager/js/windows-user-manager.js
systemctl restart pveproxy
printf '%s\n' '[PVE-WUM] UI injection removed; refresh browser with Ctrl+F5.'
