# PVE Windows User Manager 1.0.3

VM-level local Windows user management through **QEMU Guest Agent only**.

Changes in 1.0.3:
- removes the global `PVE.panel.Config` override used by 1.0.2;
- removes the old dpkg/apt auto-repair hook;
- adds the VM navigation item only after a QEMU VM config panel is initialized;
- custom card switching does not override Proxmox `activateCard()`;
- PVE 7 uses the native legacy NUL-separated `string-alist` format for `/agent/exec`;
- PVE 8/9 use the array format;
- includes `restore-panel.sh` for immediate UI rollback.

No WinRM, SSH, guest-side web service or additional port is used.
