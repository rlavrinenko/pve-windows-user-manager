#!/usr/bin/env bash
set -u
JS=/usr/share/pve-manager/js/windows-user-manager.js
IDX=/usr/share/pve-manager/index.html.tpl

echo "=== PVE Windows User Manager diagnostics ==="
echo "PVE: $(pveversion 2>/dev/null | head -n1 || true)"
echo "Manager: $(pveversion pve-manager 2>/dev/null || true)"
echo
if [[ -f "$JS" ]]; then
  grep -m1 "const VERSION" "$JS" || true
  grep -q "PVE.qemu.Config.prototype.insertNodes" "$JS" && echo "QEMU insertNodes hook: OK" || echo "QEMU insertNodes hook: MISSING"
else
  echo "JS: MISSING ($JS)"
fi
if [[ -f "$IDX" ]]; then
  grep "windows-user-manager.js" "$IDX" || echo "Loader: MISSING"
fi
if [[ $# -ge 1 ]]; then
  VMID="$1"
  NODE="${2:-$(hostname -s)}"
  echo
  echo "VM $VMID on node $NODE:"
  qm config "$VMID" 2>/dev/null | grep '^agent:' || echo "agent option: not configured"
  qm agent "$VMID" ping >/dev/null 2>&1 && echo "QEMU Guest Agent ping: OK" || echo "QEMU Guest Agent ping: FAILED"
fi
