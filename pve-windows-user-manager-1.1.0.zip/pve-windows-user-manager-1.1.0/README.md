# PVE Windows User Manager 1.1.0

VM-level local Windows user management for Proxmox VE. Windows communication is **QEMU Guest Agent only**.

This release replaces the experimental dynamic ExtJS menu hooks used by 1.0.x. The installer now inserts one normal `Ext.panel.Panel` entry directly into the existing `PVE.qemu.Config` block in `pvemanagerlib.js`. Card switching therefore remains entirely stock Proxmox behavior. The actual user manager is mounted only after that native card is visible; any runtime error is shown inside the card.

Supported operations: list local users and VM-local groups, create a local user with password, edit full name/description, change password, enable/disable the account, and update group membership. Group names come directly from the guest and UTF-8/Cyrillic is preserved.

Install:

```bash
chmod +x *.sh
./install.sh
```

Diagnostics:

```bash
./diagnose.sh 100
```

Uninstall / emergency UI restore:

```bash
./restore-panel.sh
```

A `pve-manager` package update replaces `pvemanagerlib.js`; rerun `install.sh` after such an update. No automatic dpkg/apt repair hook is installed.
