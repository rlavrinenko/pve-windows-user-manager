#!/usr/bin/env bash
set -u
VMID="${1:-}"
PVE_ROOT=/usr/share/pve-manager
INDEX="$PVE_ROOT/index.html.tpl"
BUNDLE="$PVE_ROOT/js/pvemanagerlib.js"
JS="$PVE_ROOT/js/windows-user-manager.js"

echo "=== PVE Windows User Manager 1.1.0 diagnostics ==="
echo "PVE: $(pveversion pve-manager 2>/dev/null || pveversion 2>/dev/null | head -n1)"
echo
printf 'Runtime: '; grep -m1 "const VERSION" "$JS" 2>/dev/null || echo MISSING
printf 'Native QEMU card: '; grep -q 'PVE-WUM-NATIVE-BEGIN' "$BUNDLE" && echo OK || echo MISSING
printf 'Native itemId: '; grep -q "itemId: 'windows-users'" "$BUNDLE" && echo OK || echo MISSING
printf 'Runtime loader: '; grep -q 'windows-user-manager.js?v=1.1.0' "$INDEX" && echo OK || echo MISSING
printf 'Bundle cache-buster: '; grep -q 'pvemanagerlib.js.*wum=1.1.0' "$INDEX" && echo OK || echo MISSING

echo
if [[ -n "$VMID" ]]; then
    NODE="$(hostname -s)"
    echo "VM $VMID on node $NODE:"
    qm config "$VMID" 2>/dev/null | grep '^agent:' || true
    if qm agent "$VMID" ping >/dev/null 2>&1; then echo 'QEMU Guest Agent ping: OK'; else echo 'QEMU Guest Agent ping: FAILED'; fi
fi

echo
echo 'Bundle native snippet:'
grep -n -A8 -B2 'PVE-WUM-NATIVE-BEGIN' "$BUNDLE" 2>/dev/null | head -n 14 || true
