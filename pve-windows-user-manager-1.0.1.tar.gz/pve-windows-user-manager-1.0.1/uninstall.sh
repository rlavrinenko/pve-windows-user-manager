#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Run as root" >&2; exit 1; }
INDEX="/usr/share/pve-manager/index.html.tpl"
if [[ -f "$INDEX" ]]; then
python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text(encoding='utf-8')
s='\n'.join(x for x in s.splitlines() if 'windows-user-manager.js' not in x)+'\n'
p.write_text(s,encoding='utf-8')
PY
fi
rm -f /usr/share/pve-manager/js/windows-user-manager.js
rm -f /usr/local/sbin/pve-wum-repair
rm -f /etc/apt/apt.conf.d/99-pve-windows-user-manager
rm -rf /usr/local/share/pve-windows-user-manager
echo "[PVE-WUM] Removed. Backups, if any, remain in /var/lib/pve-windows-user-manager/backups"
