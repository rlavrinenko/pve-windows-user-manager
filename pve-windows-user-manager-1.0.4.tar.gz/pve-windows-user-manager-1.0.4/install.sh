#!/usr/bin/env bash
set -euo pipefail

NAME="pve-windows-user-manager"
VERSION="1.0.4"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PVE_ROOT="/usr/share/pve-manager"
INDEX="$PVE_ROOT/index.html.tpl"
JS_DIR="$PVE_ROOT/js"
TARGET_JS="$JS_DIR/windows-user-manager.js"
BACKUP_DIR="/var/lib/$NAME/backups"
MARKER='windows-user-manager.js'

fail(){ echo "[PVE-WUM] ERROR: $*" >&2; exit 1; }
[[ ${EUID:-$(id -u)} -eq 0 ]] || fail "run as root"
command -v pveversion >/dev/null 2>&1 || fail "this host does not look like Proxmox VE"
[[ -f "$INDEX" ]] || fail "$INDEX not found"
[[ -d "$JS_DIR" ]] || fail "$JS_DIR not found"
[[ -f "$SRC_DIR/windows-user-manager.js" ]] || fail "windows-user-manager.js not found"

PVE_VER="$(pveversion pve-manager 2>/dev/null || pveversion 2>/dev/null | head -n1 || true)"
echo "[PVE-WUM] Detected: ${PVE_VER:-Proxmox VE}"

# Remove the auto-repair hook from 1.0.0-1.0.2. It was too invasive and could
# re-inject a broken UI file after pve-manager package operations.
rm -f /etc/apt/apt.conf.d/99-pve-windows-user-manager
rm -f /usr/local/sbin/pve-wum-repair
rm -rf /usr/local/share/pve-windows-user-manager

mkdir -p "$BACKUP_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
cp -a "$INDEX" "$BACKUP_DIR/index.html.tpl.$TS"
install -m 0644 "$SRC_DIR/windows-user-manager.js" "$TARGET_JS"

python3 - "$INDEX" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
line='    <script type="text/javascript" src="/pve2/js/windows-user-manager.js?v=1.0.4"></script>'
lines=[x for x in s.splitlines() if 'windows-user-manager.js' not in x]
idx=next((i for i,x in enumerate(lines) if 'pvemanagerlib.js' in x and '<script' in x), None)
if idx is None:
    raise SystemExit('Cannot find pvemanagerlib.js loader in index.html.tpl')
lines.insert(idx+1,line)
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
PY

grep -q "windows-user-manager.js?v=1.0.4" "$INDEX" || fail "UI loader was not installed"
grep -q "const VERSION = '1.0.4'" "$TARGET_JS" || fail "wrong JavaScript version installed"

echo "[PVE-WUM] Installed $VERSION"
echo "[PVE-WUM] Transport: QEMU Guest Agent only"
echo "[PVE-WUM] No PVE API files, ConfigPanel classes, WinRM, SSH or guest ports were modified."
echo "[PVE-WUM] Hard-refresh browser: Ctrl+F5"
