# PVE Windows User Manager 1.0.4

VM-level local Windows user management through **QEMU Guest Agent only**.

## Fix in 1.0.4

- fixes PVE 7.4 navigation where `Windows Users` was highlighted but the previous card stayed visible;
- registers `windows-users` in the existing per-VM `savedItems` map;
- the stock Proxmox `ConfigPanel.activateCard()` now opens/closes the module exactly like native VM sections;
- removes the custom selection/card switching logic from 1.0.3;
- does **not** override `PVE.panel.Config` or `activateCard()`;
- no WinRM, SSH, guest daemon or extra port; QEMU Guest Agent only;
- groups are discovered live from the selected Windows VM and Unicode/Cyrillic is preserved.

Install over older versions with `./install.sh`, then hard-refresh the browser.
